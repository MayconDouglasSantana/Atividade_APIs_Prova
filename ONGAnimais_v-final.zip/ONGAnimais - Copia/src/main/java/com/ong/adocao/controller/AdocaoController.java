package com.ong.adocao.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ong.adocao.exception.RegraNegocioException;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.UsuarioRepository;
import com.ong.adocao.service.AdocaoService;

@RestController
@RequestMapping("/api/candidaturas")
public class AdocaoController {

    private final AdocaoService adocaoService;
    private final UsuarioRepository usuarioRepository;

    public AdocaoController(AdocaoService adocaoService, UsuarioRepository usuarioRepository) {
        this.adocaoService = adocaoService;
        this.usuarioRepository = usuarioRepository;
    }

    @PostMapping("/{id}/aprovar")
    public ResponseEntity<Void> aprovarAdocao(
            @PathVariable Long id,
            @AuthenticationPrincipal Jwt jwt) {
        Usuario coordenador = usuarioRepository.findByEmail(jwt.getSubject())
                .orElseThrow(() -> new RegraNegocioException("Coordenador autenticado não encontrado."));
        adocaoService.aprovarAdocao(id, coordenador.getId());
        return ResponseEntity.noContent().build();
    }
}
