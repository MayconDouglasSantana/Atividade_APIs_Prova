package com.ong.adocao.service;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ong.adocao.dto.QuestionarioPerfilDTO;
import com.ong.adocao.exception.RegraNegocioException;
import com.ong.adocao.model.QuestionarioPerfil;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.QuestionarioPerfilRepository;
import com.ong.adocao.repository.UsuarioRepository;

@Service
public class QuestionarioPerfilService {

    private final QuestionarioPerfilRepository questionarioPerfilRepository;
    private final UsuarioRepository usuarioRepository;

    public QuestionarioPerfilService(
            QuestionarioPerfilRepository questionarioPerfilRepository,
            UsuarioRepository usuarioRepository) {
        this.questionarioPerfilRepository = questionarioPerfilRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @Transactional
    public QuestionarioPerfilDTO salvarOuAtualizar(Long usuarioId, QuestionarioPerfilDTO dto) {
        Usuario usuario = buscarUsuario(usuarioId);

        QuestionarioPerfil questionario = questionarioPerfilRepository
                .findByUsuarioId(usuarioId)
                .orElseGet(() -> {
                    QuestionarioPerfil novoQuestionario = new QuestionarioPerfil();
                    novoQuestionario.setUsuario(usuario);
                    return novoQuestionario;
                });

        atualizarCampos(questionario, dto);
        return toDTO(questionarioPerfilRepository.save(questionario));
    }

    @Transactional(readOnly = true)
    public QuestionarioPerfilDTO buscarPorUsuarioId(Long usuarioId) {
        if (!usuarioRepository.existsById(usuarioId)) {
            throw new RegraNegocioException("Usuário não encontrado.", HttpStatus.NOT_FOUND);
        }

        QuestionarioPerfil questionario = questionarioPerfilRepository.findByUsuarioId(usuarioId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Questionário de perfil não encontrado.",
                        HttpStatus.NOT_FOUND));

        return toDTO(questionario);
    }

    private Usuario buscarUsuario(Long usuarioId) {
        return usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Usuário não encontrado.",
                        HttpStatus.NOT_FOUND));
    }

    private void atualizarCampos(QuestionarioPerfil questionario, QuestionarioPerfilDTO dto) {
        questionario.setTipoMoradia(dto.getTipoMoradia());
        questionario.setTemQuintal(dto.isTemQuintal());
        questionario.setJanelasComTela(dto.isJanelasComTela());
        questionario.setOutrosAnimais(dto.getOutrosAnimais());
        questionario.setHorasForaDeCasa(dto.getHorasForaDeCasa());
    }

    private QuestionarioPerfilDTO toDTO(QuestionarioPerfil questionario) {
        return new QuestionarioPerfilDTO(
                questionario.getTipoMoradia(),
                questionario.isTemQuintal(),
                questionario.isJanelasComTela(),
                questionario.getOutrosAnimais(),
                questionario.getHorasForaDeCasa());
    }
}
