package com.ong.adocao.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AnimalRequestDTO {

    private String nome;
    private String especie;
    private String porte;
    private String sexo;
    private Integer idadeEstimada;
    private String temperamento;
    private String fotoUrl;
}
