package com.ong.adocao.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Version;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Candidatura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "adotante_id")
    private Usuario adotante;

    @ManyToOne
    @JoinColumn(name = "animal_id")
    private Animal animal;

    @Enumerated(EnumType.STRING)
    private StatusCandidatura status;

    private String motivoRecusa;
    private LocalDate dataCandidatura;
    private LocalDate dataAprovacao;
    private LocalDateTime agendaVisita;

    @Enumerated(EnumType.STRING)
    private RecomendacaoTriagem recomendacao;

    @ManyToOne
    @JoinColumn(name = "coordenador_aprovacao_id")
    private Usuario coordenadorAprovacao;

    @Version
    private Long versao;
}
