package com.ong.adocao.model;

public enum StatusCandidatura {
    EM_ANALISE,
    APROVADA,
    RECUSADA,
    CANCELADA
}
