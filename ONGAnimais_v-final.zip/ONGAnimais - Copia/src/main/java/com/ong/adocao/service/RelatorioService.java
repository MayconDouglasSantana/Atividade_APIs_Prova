package com.ong.adocao.service;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ong.adocao.dto.AdocoesPorMesDTO;
import com.ong.adocao.dto.AcompanhamentoAtrasadoDTO;
import com.ong.adocao.dto.TempoMedioAdocaoDTO;
import com.ong.adocao.model.Acompanhamento;
import com.ong.adocao.model.Candidatura;
import com.ong.adocao.model.StatusAcompanhamento;
import com.ong.adocao.model.StatusCandidatura;
import com.ong.adocao.repository.AcompanhamentoRepository;
import com.ong.adocao.repository.CandidaturaRepository;

@Service
public class RelatorioService {

    private final CandidaturaRepository candidaturaRepository;
    private final AcompanhamentoRepository acompanhamentoRepository;

    public RelatorioService(
            CandidaturaRepository candidaturaRepository,
            AcompanhamentoRepository acompanhamentoRepository) {
        this.candidaturaRepository = candidaturaRepository;
        this.acompanhamentoRepository = acompanhamentoRepository;
    }

    @Transactional(readOnly = true)
    public List<AdocoesPorMesDTO> adocoesPorMes() {
        Map<YearMonth, Long> totaisPorMes = new TreeMap<>();
        for (Candidatura candidatura : buscarAdocoesAprovadas()) {
            totaisPorMes.merge(YearMonth.from(candidatura.getDataAprovacao()), 1L, Long::sum);
        }

        return totaisPorMes.entrySet().stream()
                .map(entry -> new AdocoesPorMesDTO(
                        entry.getKey().getYear(),
                        entry.getKey().getMonthValue(),
                        entry.getValue()))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<TempoMedioAdocaoDTO> tempoMedioAdocao() {
        List<Candidatura> adocoes = buscarAdocoesAprovadas().stream()
                .filter(candidatura -> candidatura.getAnimal().getDataEntrada() != null)
                .toList();

        Map<String, List<Candidatura>> adocoesPorEspecieEPorte = new TreeMap<>();
        for (Candidatura candidatura : adocoes) {
            String chave = candidatura.getAnimal().getEspecie() + "\u0000"
                    + candidatura.getAnimal().getPorte();
            adocoesPorEspecieEPorte.computeIfAbsent(chave, ignored -> new ArrayList<>())
                    .add(candidatura);
        }

        return adocoesPorEspecieEPorte.values().stream()
                .map(grupo -> {
                    Candidatura primeira = grupo.get(0);
                    double mediaDias = grupo.stream()
                            .mapToLong(candidatura -> ChronoUnit.DAYS.between(
                                    candidatura.getAnimal().getDataEntrada(),
                                    candidatura.getDataAprovacao()))
                            .average()
                            .orElseThrow();
                    return new TempoMedioAdocaoDTO(
                            primeira.getAnimal().getEspecie(),
                            primeira.getAnimal().getPorte(),
                            grupo.size(),
                            mediaDias);
                })
                .sorted(Comparator.comparing(
                                TempoMedioAdocaoDTO::getEspecie,
                                Comparator.nullsFirst(String::compareTo))
                        .thenComparing(
                                TempoMedioAdocaoDTO::getPorte,
                                Comparator.nullsFirst(String::compareTo)))
                .toList();
    }

    @Transactional
    public List<AcompanhamentoAtrasadoDTO> acompanhamentosAtrasados() {
        List<Acompanhamento> vencidosPendentes =
                acompanhamentoRepository.findByStatusAndDataPrevistaBefore(
                        StatusAcompanhamento.PENDENTE,
                        LocalDate.now());
        for (Acompanhamento acompanhamento : vencidosPendentes) {
            acompanhamento.setStatus(StatusAcompanhamento.ATRASADO);
        }
        acompanhamentoRepository.saveAll(vencidosPendentes);

        Collection<StatusAcompanhamento> statuses = List.of(StatusAcompanhamento.ATRASADO);

        return acompanhamentoRepository.findByDataPrevistaBeforeAndStatusIn(LocalDate.now(), statuses)
                .stream()
                .map(acompanhamento -> new AcompanhamentoAtrasadoDTO(
                        acompanhamento.getId(),
                        acompanhamento.getAnimal().getId(),
                        acompanhamento.getAnimal().getNome(),
                        acompanhamento.getAdotante().getId(),
                        acompanhamento.getAdotante().getNome(),
                        acompanhamento.getDataPrevista(),
                        acompanhamento.getStatus()))
                .toList();
    }

    private List<Candidatura> buscarAdocoesAprovadas() {
        return candidaturaRepository.findByStatusAndDataAprovacaoIsNotNull(
                StatusCandidatura.APROVADA);
    }
}
