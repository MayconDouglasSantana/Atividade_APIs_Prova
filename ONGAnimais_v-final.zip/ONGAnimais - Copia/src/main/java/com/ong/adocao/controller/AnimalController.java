package com.ong.adocao.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ong.adocao.dto.AnimalRequestDTO;
import com.ong.adocao.dto.AnimalResponseDTO;
import com.ong.adocao.service.AnimalService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/animais")
public class AnimalController {

    private final AnimalService animalService;

    public AnimalController(AnimalService animalService) {
        this.animalService = animalService;
    }

    @PostMapping
    public ResponseEntity<AnimalResponseDTO> cadastrar(@Valid @RequestBody AnimalRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(animalService.cadastrar(dto));
    }

    @PutMapping("/{id}/disponivel")
    public ResponseEntity<AnimalResponseDTO> marcarComoDisponivel(@PathVariable Long id) {
        return ResponseEntity.ok(animalService.marcarComoDisponivel(id));
    }

    @GetMapping("/disponiveis")
    public ResponseEntity<Page<AnimalResponseDTO>> buscarDisponiveis(
            @RequestParam(required = false) String especie,
            @RequestParam(required = false) String porte,
            @RequestParam(required = false) String sexo,
            @RequestParam(required = false) Integer idadeMinima,
            @RequestParam(required = false) Integer idadeMaxima,
            Pageable pageable) {
        return ResponseEntity.ok(animalService.buscarDisponiveis(
                especie, porte, sexo, idadeMinima, idadeMaxima, pageable));
    }
}
