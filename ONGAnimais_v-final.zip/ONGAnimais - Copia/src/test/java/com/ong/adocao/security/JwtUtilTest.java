package com.ong.adocao.security;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.junit.jupiter.api.Test;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtEncoder;

import com.nimbusds.jose.jwk.source.ImmutableSecret;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class JwtUtilTest {

    private static final SecretKey SECRET_KEY = new SecretKeySpec(
            "a-test-secret-with-at-least-32-bytes-long".getBytes(java.nio.charset.StandardCharsets.UTF_8),
            "HmacSHA256");
    private static final JwtUtil JWT_UTIL = new JwtUtil(
            new NimbusJwtEncoder(new ImmutableSecret<>(SECRET_KEY)),
            3600);
    private static final JwtDecoder JWT_DECODER = NimbusJwtDecoder.withSecretKey(SECRET_KEY)
            .macAlgorithm(MacAlgorithm.HS256)
            .build();

    @Test
    void geraTokenCompativelComDecoderDoSpringSecurity() {
        String token = JWT_UTIL.gerarToken("adotante@ong.com", "ROLE_ADOTANTE");
        Jwt jwt = JWT_DECODER.decode(token);

        assertEquals("adotante@ong.com", jwt.getSubject());
        assertEquals("ROLE_ADOTANTE", jwt.getClaimAsString("perfil"));
        assertEquals("https://ong-adocao.local", jwt.getIssuer().toString());
    }

    @Test
    void rejeitaTokenComAssinaturaAlterada() {
        String token = JWT_UTIL.gerarToken("adotante@ong.com", "ROLE_ADOTANTE");
        String tokenAlterado = token.substring(0, token.lastIndexOf('.') + 1) + "assinatura-invalida";

        assertThrows(JwtException.class, () -> JWT_DECODER.decode(tokenAlterado));
    }
}
