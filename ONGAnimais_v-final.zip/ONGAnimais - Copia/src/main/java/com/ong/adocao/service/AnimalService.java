package com.ong.adocao.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

import com.ong.adocao.dto.AnimalRequestDTO;
import com.ong.adocao.dto.AnimalResponseDTO;
import com.ong.adocao.exception.RegraNegocioException;
import com.ong.adocao.model.Animal;
import com.ong.adocao.model.StatusAnimal;
import com.ong.adocao.model.TipoCuidado;
import com.ong.adocao.repository.AnimalRepository;
import com.ong.adocao.repository.CuidadoSaudeRepository;

@Service
public class AnimalService {

    private final AnimalRepository animalRepository;
    private final CuidadoSaudeRepository cuidadoSaudeRepository;

    public AnimalService(
            AnimalRepository animalRepository,
            CuidadoSaudeRepository cuidadoSaudeRepository) {
        this.animalRepository = animalRepository;
        this.cuidadoSaudeRepository = cuidadoSaudeRepository;
    }

    @Transactional
    public AnimalResponseDTO cadastrar(AnimalRequestDTO dto) {
        Animal animal = new Animal();
        animal.setNome(dto.getNome());
        animal.setEspecie(dto.getEspecie());
        animal.setPorte(dto.getPorte());
        animal.setSexo(dto.getSexo());
        animal.setIdadeEstimada(dto.getIdadeEstimada());
        animal.setTemperamento(dto.getTemperamento());
        animal.setFotoUrl(dto.getFotoUrl());
        animal.setDataEntrada(LocalDate.now());
        animal.setStatus(StatusAnimal.EM_TRATAMENTO);

        return toResponseDTO(animalRepository.save(animal));
    }

    @Transactional
    public AnimalResponseDTO marcarComoDisponivel(Long animalId) {
        Animal animal = animalRepository.findByIdForUpdate(animalId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Animal não encontrado.",
                        HttpStatus.NOT_FOUND));

        boolean possuiCastracao = cuidadoSaudeRepository.existsByAnimalIdAndTipo(
                animalId,
                TipoCuidado.CASTRACAO);
        boolean possuiVacina = cuidadoSaudeRepository.existsByAnimalIdAndTipo(
                animalId,
                TipoCuidado.VACINA);

        if (!possuiCastracao || !possuiVacina) {
            throw new RegraNegocioException(
                    "O animal precisa ter registro de castração e vacina para ficar disponível.");
        }

        animal.setStatus(StatusAnimal.DISPONIVEL);
        return toResponseDTO(animalRepository.save(animal));
    }

    @Transactional(readOnly = true)
    public Page<AnimalResponseDTO> buscarDisponiveis(
            String especie,
            String porte,
            String sexo,
            Integer idadeMinima,
            Integer idadeMaxima,
            Pageable pageable) {
        if ((idadeMinima != null && idadeMinima < 0)
                || (idadeMaxima != null && idadeMaxima < 0)) {
            throw new RegraNegocioException("A idade não pode ser negativa.");
        }
        if (idadeMinima != null && idadeMaxima != null && idadeMinima > idadeMaxima) {
            throw new RegraNegocioException("A idade mínima não pode ser maior que a idade máxima.");
        }
        return animalRepository.buscarPorFiltros(
                        StatusAnimal.DISPONIVEL,
                        normalizarFiltro(especie),
                        normalizarFiltro(porte),
                        normalizarFiltro(sexo),
                        idadeMinima,
                        idadeMaxima,
                        pageable)
                .map(this::toResponseDTO);
    }

    private String normalizarFiltro(String filtro) {
        return filtro == null || filtro.isBlank() ? null : filtro;
    }

    private AnimalResponseDTO toResponseDTO(Animal animal) {
        return new AnimalResponseDTO(
                animal.getId(),
                animal.getNome(),
                animal.getEspecie(),
                animal.getPorte(),
                animal.getSexo(),
                animal.getIdadeEstimada(),
                animal.getTemperamento(),
                animal.getFotoUrl(),
                animal.getDataEntrada(),
                animal.getStatus());
    }
}
