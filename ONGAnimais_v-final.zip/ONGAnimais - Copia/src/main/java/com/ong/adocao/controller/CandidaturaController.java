package com.ong.adocao.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ong.adocao.dto.CandidaturaRequestDTO;
import com.ong.adocao.dto.CandidaturaResponseDTO;
import com.ong.adocao.dto.TriagemDTO;
import com.ong.adocao.exception.RegraNegocioException;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.UsuarioRepository;
import com.ong.adocao.service.CandidaturaService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/candidaturas")
public class CandidaturaController {

    private final CandidaturaService candidaturaService;
    private final UsuarioRepository usuarioRepository;

    public CandidaturaController(
            CandidaturaService candidaturaService,
            UsuarioRepository usuarioRepository) {
        this.candidaturaService = candidaturaService;
        this.usuarioRepository = usuarioRepository;
    }

    @PostMapping
    public ResponseEntity<CandidaturaResponseDTO> candidatar(
            @AuthenticationPrincipal Jwt jwt,
            @Valid @RequestBody CandidaturaRequestDTO dto) {
        CandidaturaResponseDTO candidatura =
                candidaturaService.candidatar(buscarAdotante(jwt).getId(), dto.getAnimalId());
        return ResponseEntity.status(HttpStatus.CREATED).body(candidatura);
    }

    @GetMapping("/minhas")
    public ResponseEntity<List<CandidaturaResponseDTO>> buscarMinhas(
            @AuthenticationPrincipal Jwt jwt) {
        return ResponseEntity.ok(candidaturaService.buscarMinhas(buscarAdotante(jwt).getId()));
    }

    @DeleteMapping("/{id}/cancelar")
    public ResponseEntity<Void> cancelar(
            @PathVariable Long id,
            @AuthenticationPrincipal Jwt jwt) {
        candidaturaService.cancelarCandidatura(id, buscarAdotante(jwt).getId());
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/triagem")
    public ResponseEntity<TriagemDTO> avaliarTriagem(
            @PathVariable Long id,
            @Valid @RequestBody TriagemDTO dto) {
        return ResponseEntity.ok(candidaturaService.avaliarTriagem(id, dto));
    }

    private Usuario buscarAdotante(Jwt jwt) {
        return usuarioRepository.findByEmail(jwt.getSubject())
                .orElseThrow(() -> new RegraNegocioException("Usuário autenticado não encontrado."));
    }
}
