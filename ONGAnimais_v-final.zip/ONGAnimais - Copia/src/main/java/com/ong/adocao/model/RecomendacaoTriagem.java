package com.ong.adocao.model;

public enum RecomendacaoTriagem {
    APROVAR,
    RECUSAR
}
