package com.ong.adocao.service;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ong.adocao.model.Acompanhamento;
import com.ong.adocao.model.Animal;
import com.ong.adocao.model.Candidatura;
import com.ong.adocao.model.StatusAcompanhamento;
import com.ong.adocao.model.StatusCandidatura;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.AcompanhamentoRepository;
import com.ong.adocao.repository.CandidaturaRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class RelatorioServiceTest {

    private CandidaturaRepository candidaturaRepository;
    private AcompanhamentoRepository acompanhamentoRepository;
    private RelatorioService relatorioService;

    @BeforeEach
    void setUp() {
        candidaturaRepository = mock(CandidaturaRepository.class);
        acompanhamentoRepository = mock(AcompanhamentoRepository.class);
        relatorioService = new RelatorioService(candidaturaRepository, acompanhamentoRepository);
    }

    @Test
    void calculaTempoDesdeEntradaAgrupadoPorEspecieEPorte() {
        when(candidaturaRepository.findByStatusAndDataAprovacaoIsNotNull(StatusCandidatura.APROVADA))
                .thenReturn(List.of(
                        adocao("Cachorro", "Grande", LocalDate.of(2026, 1, 1),
                                LocalDate.of(2026, 1, 11)),
                        adocao("Cachorro", "Grande", LocalDate.of(2026, 1, 1),
                                LocalDate.of(2026, 1, 21)),
                        adocao("Gato", "Pequeno", LocalDate.of(2026, 2, 1),
                                LocalDate.of(2026, 2, 6))));

        var relatorios = relatorioService.tempoMedioAdocao();

        assertEquals(2, relatorios.size());
        assertEquals("Cachorro", relatorios.get(0).getEspecie());
        assertEquals("Grande", relatorios.get(0).getPorte());
        assertEquals(2, relatorios.get(0).getTotalAdocoes());
        assertEquals(15.0, relatorios.get(0).getMediaDias());
        assertEquals("Gato", relatorios.get(1).getEspecie());
        assertEquals(5.0, relatorios.get(1).getMediaDias());
    }

    @Test
    void relatorioMarcaAcompanhamentosVencidosComoAtrasados() {
        Acompanhamento acompanhamento = new Acompanhamento();
        acompanhamento.setId(1L);
        acompanhamento.setAnimal(animal(2L, "Luna"));
        Usuario adotante = new Usuario();
        adotante.setId(3L);
        adotante.setNome("Joana");
        acompanhamento.setAdotante(adotante);
        acompanhamento.setDataPrevista(LocalDate.now().minusDays(1));
        acompanhamento.setStatus(StatusAcompanhamento.PENDENTE);

        when(acompanhamentoRepository.findByStatusAndDataPrevistaBefore(
                StatusAcompanhamento.PENDENTE, LocalDate.now()))
                .thenReturn(List.of(acompanhamento));
        when(acompanhamentoRepository.findByDataPrevistaBeforeAndStatusIn(
                LocalDate.now(), List.of(StatusAcompanhamento.ATRASADO)))
                .thenReturn(List.of(acompanhamento));

        var atrasados = relatorioService.acompanhamentosAtrasados();

        assertEquals(StatusAcompanhamento.ATRASADO, acompanhamento.getStatus());
        assertEquals(StatusAcompanhamento.ATRASADO, atrasados.get(0).getStatus());
        verify(acompanhamentoRepository).saveAll(List.of(acompanhamento));
    }

    private Candidatura adocao(
            String especie,
            String porte,
            LocalDate dataEntrada,
            LocalDate dataAprovacao) {
        Animal animal = animal(null, null);
        animal.setEspecie(especie);
        animal.setPorte(porte);
        animal.setDataEntrada(dataEntrada);
        Candidatura candidatura = new Candidatura();
        candidatura.setAnimal(animal);
        candidatura.setStatus(StatusCandidatura.APROVADA);
        candidatura.setDataAprovacao(dataAprovacao);
        return candidatura;
    }

    private Animal animal(Long id, String nome) {
        Animal animal = new Animal();
        animal.setId(id);
        animal.setNome(nome);
        return animal;
    }
}
