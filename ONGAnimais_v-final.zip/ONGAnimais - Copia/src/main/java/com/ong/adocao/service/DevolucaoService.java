package com.ong.adocao.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ong.adocao.exception.RegraNegocioException;
import com.ong.adocao.model.Acompanhamento;
import com.ong.adocao.model.Animal;
import com.ong.adocao.model.StatusAcompanhamento;
import com.ong.adocao.model.StatusAnimal;
import com.ong.adocao.model.StatusCandidatura;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.AcompanhamentoRepository;
import com.ong.adocao.repository.AnimalRepository;
import com.ong.adocao.repository.CandidaturaRepository;
import com.ong.adocao.repository.UsuarioRepository;

@Service
public class DevolucaoService {

    private final AnimalRepository animalRepository;
    private final UsuarioRepository usuarioRepository;
    private final CandidaturaRepository candidaturaRepository;
    private final AcompanhamentoRepository acompanhamentoRepository;

    public DevolucaoService(
            AnimalRepository animalRepository,
            UsuarioRepository usuarioRepository,
            CandidaturaRepository candidaturaRepository,
            AcompanhamentoRepository acompanhamentoRepository) {
        this.animalRepository = animalRepository;
        this.usuarioRepository = usuarioRepository;
        this.candidaturaRepository = candidaturaRepository;
        this.acompanhamentoRepository = acompanhamentoRepository;
    }

    @Transactional
    public void registrarDevolucao(Long animalId, Long adotanteId) {
        Animal animal = animalRepository.findById(animalId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Animal não encontrado.",
                        HttpStatus.NOT_FOUND));
        Usuario adotante = usuarioRepository.findById(adotanteId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Adotante não encontrado.",
                        HttpStatus.NOT_FOUND));

        if (animal.getStatus() != StatusAnimal.ADOTADO
                || candidaturaRepository.findByAnimalIdAndAdotanteIdAndStatus(
                        animalId,
                        adotanteId,
                        StatusCandidatura.APROVADA).isEmpty()) {
            throw new RegraNegocioException(
                    "Não foi encontrada uma adoção ativa deste animal para o adotante.");
        }

        animal.setStatus(StatusAnimal.EM_TRATAMENTO);
        animalRepository.save(animal);

        List<Acompanhamento> acompanhamentosPendentes =
                acompanhamentoRepository.findByAnimalIdAndAdotanteIdAndStatusIn(
                        animalId,
                        adotanteId,
                        List.of(StatusAcompanhamento.PENDENTE, StatusAcompanhamento.ATRASADO));
        for (Acompanhamento acompanhamento : acompanhamentosPendentes) {
            acompanhamento.setStatus(StatusAcompanhamento.CANCELADO);
        }
        acompanhamentoRepository.saveAll(acompanhamentosPendentes);

        adotante.setBloqueadoAte(LocalDate.now().plusYears(1));
        usuarioRepository.save(adotante);
    }
}
