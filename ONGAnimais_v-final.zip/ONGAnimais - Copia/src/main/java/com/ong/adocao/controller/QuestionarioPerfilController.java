package com.ong.adocao.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ong.adocao.dto.QuestionarioPerfilDTO;
import com.ong.adocao.exception.RegraNegocioException;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.UsuarioRepository;
import com.ong.adocao.service.QuestionarioPerfilService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/questionarios")
public class QuestionarioPerfilController {

    private final QuestionarioPerfilService questionarioPerfilService;
    private final UsuarioRepository usuarioRepository;

    public QuestionarioPerfilController(
            QuestionarioPerfilService questionarioPerfilService,
            UsuarioRepository usuarioRepository) {
        this.questionarioPerfilService = questionarioPerfilService;
        this.usuarioRepository = usuarioRepository;
    }

    @PostMapping
    public ResponseEntity<QuestionarioPerfilDTO> salvarOuAtualizar(
            @AuthenticationPrincipal Jwt jwt,
            @Valid @RequestBody QuestionarioPerfilDTO dto) {
        return ResponseEntity.ok(questionarioPerfilService.salvarOuAtualizar(
                buscarUsuario(jwt).getId(),
                dto));
    }

    @GetMapping("/meu-perfil")
    public ResponseEntity<QuestionarioPerfilDTO> buscarMeuPerfil(
            @AuthenticationPrincipal Jwt jwt) {
        return ResponseEntity.ok(questionarioPerfilService.buscarPorUsuarioId(
                buscarUsuario(jwt).getId()));
    }

    private Usuario buscarUsuario(Jwt jwt) {
        return usuarioRepository.findByEmail(jwt.getSubject())
                .orElseThrow(() -> new RegraNegocioException("Usuário autenticado não encontrado."));
    }
}
