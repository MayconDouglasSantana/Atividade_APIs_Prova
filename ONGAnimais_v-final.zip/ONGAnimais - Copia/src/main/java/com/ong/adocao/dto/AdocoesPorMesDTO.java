package com.ong.adocao.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdocoesPorMesDTO {

    private int ano;
    private int mes;
    private long total;
}
