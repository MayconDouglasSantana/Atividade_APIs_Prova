package com.ong.adocao.repository;

import java.util.List;
import java.util.Optional;

import jakarta.persistence.LockModeType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ong.adocao.model.Animal;
import com.ong.adocao.model.StatusAnimal;

public interface AnimalRepository extends JpaRepository<Animal, Long> {

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT a FROM Animal a WHERE a.id = :id")
    Optional<Animal> findByIdForUpdate(@Param("id") Long id);

    Page<Animal> findByEspecieAndPorteAndSexoAndStatus(
            String especie,
            String porte,
            String sexo,
            StatusAnimal status,
            Pageable pageable);

    @Query("""
            SELECT a FROM Animal a
            WHERE a.status = :status
              AND (:especie IS NULL OR a.especie = :especie)
              AND (:porte IS NULL OR a.porte = :porte)
              AND (:sexo IS NULL OR a.sexo = :sexo)
              AND (:idadeMinima IS NULL OR a.idadeEstimada >= :idadeMinima)
              AND (:idadeMaxima IS NULL OR a.idadeEstimada <= :idadeMaxima)
            """)
    Page<Animal> buscarPorFiltros(
            @Param("status") StatusAnimal status,
            @Param("especie") String especie,
            @Param("porte") String porte,
            @Param("sexo") String sexo,
            @Param("idadeMinima") Integer idadeMinima,
            @Param("idadeMaxima") Integer idadeMaxima,
            Pageable pageable);

    List<Animal> findByStatus(StatusAnimal status);
}
