package ifsp.apis.ONGAnimais;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ong.adocao.repository.UsuarioRepository;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("demo")
class ApiEndpointsIntegrationTest {

    private static final String BASE_URL = "/api";

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Test
    void cadastroLoginQuestionarioEProtecaoDeDados() throws Exception {
        String sufixo = UUID.randomUUID().toString();
        String email = "adotante-" + sufixo + "@example.com";
        String cadastroJson = """
                {
                  "nome": "Adotante de integracao",
                  "cpf": "%s",
                  "email": "%s",
                  "telefone": "11999999999",
                  "endereco": "Rua de Teste, 10",
                  "senha": "senha-teste-123"
                }
                """.formatted(sufixo, email);

        MvcResult cadastro = mockMvc.perform(post(BASE_URL + "/usuarios/cadastrar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(cadastroJson))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").isNumber())
                .andExpect(jsonPath("$.perfil").value("ADOTANTE"))
                .andExpect(jsonPath("$.senha").doesNotExist())
                .andReturn();
        long adotanteId = objectMapper.readTree(cadastro.getResponse().getContentAsString())
                .get("id").asLong();

        mockMvc.perform(post(BASE_URL + "/usuarios/cadastrar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(cadastroJson))
                .andExpect(status().isBadRequest());
        mockMvc.perform(post(BASE_URL + "/usuarios/cadastrar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "nome": "",
                                  "cpf": "cpf-invalido",
                                  "email": "email-invalido",
                                  "telefone": "",
                                  "endereco": "",
                                  "senha": "123"
                                }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").exists());

        mockMvc.perform(post(BASE_URL + "/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"email":"inexistente@example.com","senha":"senha-errada"}
                                """))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("E-mail ou senha inválidos."));

        UserSession adotante = login(email, "senha-teste-123");
        UserSession voluntario = login("voluntario@ong.local", "Voluntario123!");
        mockMvc.perform(get(BASE_URL + "/questionarios/meu-perfil")
                        .header("Authorization", bearer(voluntario.token())))
                .andExpect(status().isForbidden());
        mockMvc.perform(get(BASE_URL + "/questionarios/meu-perfil"))
                .andExpect(status().isUnauthorized());

        String questionario = """
                {
                  "tipoMoradia": "CASA",
                  "temQuintal": true,
                  "janelasComTela": true,
                  "outrosAnimais": "Nenhum",
                  "horasForaDeCasa": 8
                }
                """;
        mockMvc.perform(post(BASE_URL + "/questionarios")
                        .header("Authorization", bearer(adotante.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(questionario))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.tipoMoradia").value("CASA"));
        mockMvc.perform(get(BASE_URL + "/questionarios/meu-perfil")
                        .header("Authorization", bearer(adotante.token())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.horasForaDeCasa").value(8));
        mockMvc.perform(post(BASE_URL + "/questionarios")
                        .header("Authorization", bearer(adotante.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(questionario.replace("\"CASA\"", "\"APARTAMENTO\"")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.tipoMoradia").value("APARTAMENTO"));

        org.junit.jupiter.api.Assertions.assertTrue(adotante.id() > 0);
        mockMvc.perform(post(BASE_URL + "/animais")
                        .header("Authorization", bearer(adotante.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isForbidden());
    }

    @Test
    void percorreFluxoDeAnimalAteDevolucaoEConsultaRelatorios() throws Exception {
        String sufixo = UUID.randomUUID().toString();
        UserSession adotante = criarAdotante(sufixo);
        UserSession voluntario = login("voluntario@ong.local", "Voluntario123!");
        UserSession coordenador = login("coordenador@ong.local", "Coordenador123!");
        salvarQuestionario(adotante, true, true);

        String animalJson = """
                {
                  "nome": "Rex-%s",
                  "especie": "Cachorro",
                  "porte": "Grande",
                  "sexo": "Macho",
                  "idadeEstimada": 3,
                  "temperamento": "Dócil",
                  "fotoUrl": "https://example.com/rex.jpg"
                }
                """.formatted(sufixo);
        MvcResult animalCriado = mockMvc.perform(post(BASE_URL + "/animais")
                        .header("Authorization", bearer(voluntario.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(animalJson))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.status").value("EM_TRATAMENTO"))
                .andExpect(jsonPath("$.dataEntrada").exists())
                .andReturn();
        long animalId = jsonLong(animalCriado, "id");

        mockMvc.perform(put(BASE_URL + "/animais/" + animalId + "/disponivel")
                        .header("Authorization", bearer(voluntario.token())))
                .andExpect(status().isBadRequest());
        registrarCuidado(animalId, voluntario, "VACINA");
        registrarCuidado(animalId, voluntario, "VERMIFUGACAO");
        registrarCuidado(animalId, voluntario, "CASTRACAO");
        mockMvc.perform(put(BASE_URL + "/animais/" + animalId + "/disponivel")
                        .header("Authorization", bearer(voluntario.token())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("DISPONIVEL"));
        mockMvc.perform(get(BASE_URL + "/animais/disponiveis")
                        .param("especie", "Cachorro")
                        .param("porte", "Grande")
                        .param("sexo", "Macho")
                        .param("idadeMinima", "3")
                        .param("idadeMaxima", "3")
                        .param("page", "0")
                        .param("size", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[?(@.id == " + animalId + ")]").exists());
        mockMvc.perform(get(BASE_URL + "/animais/disponiveis")
                        .param("idadeMinima", "5")
                        .param("idadeMaxima", "2"))
                .andExpect(status().isBadRequest());

        MvcResult candidaturaCriada = mockMvc.perform(post(BASE_URL + "/candidaturas")
                        .header("Authorization", bearer(adotante.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"animalId\":" + animalId + "}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.status").value("EM_ANALISE"))
                .andReturn();
        long candidaturaId = jsonLong(candidaturaCriada, "id");
        mockMvc.perform(get(BASE_URL + "/candidaturas/minhas")
                        .header("Authorization", bearer(adotante.token())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(candidaturaId));
        mockMvc.perform(get(BASE_URL + "/candidaturas/minhas")
                        .header("Authorization", bearer(voluntario.token())))
                .andExpect(status().isForbidden());

        mockMvc.perform(post(BASE_URL + "/candidaturas/" + candidaturaId + "/triagem")
                        .header("Authorization", bearer(voluntario.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "agendaVisita": "2026-11-01T14:00:00",
                                  "recomendacao": "APROVAR",
                                  "motivoRecusa": null
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.recomendacao").value("APROVAR"));
        mockMvc.perform(post(BASE_URL + "/candidaturas/" + candidaturaId + "/aprovar")
                        .header("Authorization", bearer(coordenador.token())))
                .andExpect(status().isNoContent());

        mockMvc.perform(get(BASE_URL + "/relatorios/adocoes-por-mes")
                        .header("Authorization", bearer(coordenador.token())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());
        mockMvc.perform(get(BASE_URL + "/relatorios/tempo-medio-adocao")
                        .header("Authorization", bearer(coordenador.token())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[?(@.especie == 'Cachorro' && @.porte == 'Grande')]").exists());
        mockMvc.perform(get(BASE_URL + "/relatorios/acompanhamentos-atrasados")
                        .header("Authorization", bearer(coordenador.token())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());
        mockMvc.perform(get(BASE_URL + "/relatorios/adocoes-por-mes")
                        .header("Authorization", bearer(adotante.token())))
                .andExpect(status().isForbidden());

        MvcResult acompanhamentos = mockMvc.perform(get(
                                BASE_URL + "/acompanhamentos/animal/" + animalId)
                        .header("Authorization", bearer(voluntario.token())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(3))
                .andReturn();
        JsonNode acompanhamentosJson = objectMapper.readTree(
                acompanhamentos.getResponse().getContentAsString());
        long acompanhamentoId = acompanhamentosJson.get(0).get("id").asLong();
        mockMvc.perform(post(BASE_URL + "/acompanhamentos/" + acompanhamentoId + "/visita")
                        .header("Authorization", bearer(voluntario.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"resultado\":\"Animal adaptado ao novo lar.\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("REALIZADO"))
                .andExpect(jsonPath("$.voluntarioId").value(voluntario.id()));
        mockMvc.perform(get(BASE_URL + "/acompanhamentos/animal/" + animalId)
                        .header("Authorization", bearer(coordenador.token())))
                .andExpect(status().isOk());

        mockMvc.perform(post(BASE_URL + "/animais/" + animalId + "/devolucao")
                        .header("Authorization", bearer(voluntario.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"adotanteId\":" + adotante.id() + "}"))
                .andExpect(status().isNoContent());
        mockMvc.perform(get(BASE_URL + "/acompanhamentos/animal/" + animalId)
                        .header("Authorization", bearer(voluntario.token())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[?(@.status == 'CANCELADO')]").exists());
        mockMvc.perform(post(BASE_URL + "/candidaturas")
                        .header("Authorization", bearer(adotante.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"animalId\":" + animalId + "}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("bloqueado")));
    }

    @Test
    void triagemRecusadaFechaCandidaturaEDeixaAnimalDisponivel() throws Exception {
        String sufixo = UUID.randomUUID().toString();
        UserSession adotante = criarAdotante(sufixo);
        UserSession voluntario = login("voluntario@ong.local", "Voluntario123!");
        salvarQuestionario(adotante, false, false);

        long animalId = criarAnimalDisponivel(
                voluntario,
                "Animal triagem " + sufixo,
                "Cachorro",
                "Pequeno",
                "Fêmea",
                2);
        MvcResult candidatura = mockMvc.perform(post(BASE_URL + "/candidaturas")
                        .header("Authorization", bearer(adotante.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"animalId\":" + animalId + "}"))
                .andExpect(status().isCreated())
                .andReturn();
        long candidaturaId = jsonLong(candidatura, "id");

        mockMvc.perform(post(BASE_URL + "/candidaturas/" + candidaturaId + "/triagem")
                        .header("Authorization", bearer(voluntario.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "agendaVisita": "2026-11-02T10:00:00",
                                  "recomendacao": "RECUSAR",
                                  "motivoRecusa": "Condicoes da residencia inadequadas"
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.motivoRecusa")
                        .value("Condicoes da residencia inadequadas"));
        mockMvc.perform(get(BASE_URL + "/candidaturas/minhas")
                        .header("Authorization", bearer(adotante.token())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].status").value("RECUSADA"));
        mockMvc.perform(get(BASE_URL + "/animais/disponiveis")
                        .param("especie", "Cachorro")
                        .param("sexo", "Fêmea")
                        .param("idadeMinima", "2")
                        .param("idadeMaxima", "2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[?(@.id == " + animalId + ")]").exists());
        mockMvc.perform(post(BASE_URL + "/candidaturas/" + candidaturaId + "/triagem")
                        .header("Authorization", bearer(voluntario.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "agendaVisita": "2026-11-03T10:00:00",
                                  "recomendacao": "RECUSAR",
                                  "motivoRecusa": "Outro motivo"
                                }
                                """))
                .andExpect(status().isBadRequest());
    }

    @Test
    void adotantePodeCancelarSomenteCandidaturaPropriaEmAnalise() throws Exception {
        String sufixo = UUID.randomUUID().toString();
        UserSession adotante = criarAdotante(sufixo);
        UserSession outroAdotante = criarAdotante(UUID.randomUUID().toString());
        UserSession voluntario = login("voluntario@ong.local", "Voluntario123!");
        salvarQuestionario(adotante, true, true);
        salvarQuestionario(outroAdotante, true, true);

        long animalId = criarAnimalDisponivel(
                voluntario,
                "Animal cancelamento " + sufixo,
                "Gato",
                "Pequeno",
                "Macho",
                1);
        long candidaturaId = criarCandidatura(adotante, animalId);
        mockMvc.perform(delete(BASE_URL + "/candidaturas/" + candidaturaId + "/cancelar")
                        .header("Authorization", bearer(outroAdotante.token())))
                .andExpect(status().isNotFound());
        mockMvc.perform(delete(BASE_URL + "/candidaturas/" + candidaturaId + "/cancelar")
                        .header("Authorization", bearer(adotante.token())))
                .andExpect(status().isNoContent());
        mockMvc.perform(get(BASE_URL + "/candidaturas/minhas")
                        .header("Authorization", bearer(adotante.token())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].status").value("CANCELADA"));
        mockMvc.perform(get(BASE_URL + "/animais/disponiveis")
                        .param("especie", "Gato")
                        .param("idadeMinima", "1")
                        .param("idadeMaxima", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[?(@.id == " + animalId + ")]").exists());
    }

    private UserSession criarAdotante(String sufixo) throws Exception {
        String email = "adotante-" + sufixo + "@example.com";
        MvcResult response = mockMvc.perform(post(BASE_URL + "/usuarios/cadastrar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "nome": "Adotante %s",
                                  "cpf": "%s",
                                  "email": "%s",
                                  "telefone": "11999999999",
                                  "endereco": "Rua de Teste, 10",
                                  "senha": "senha-teste-123"
                                }
                                """.formatted(sufixo, sufixo, email)))
                .andExpect(status().isCreated())
                .andReturn();
        long id = jsonLong(response, "id");
        return new UserSession(id, email, login(email, "senha-teste-123").token());
    }

    private UserSession login(String email, String senha) throws Exception {
        MvcResult response = mockMvc.perform(post(BASE_URL + "/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(new LoginBody(email, senha))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").isNotEmpty())
                .andExpect(jsonPath("$.tipo").value("Bearer"))
                .andReturn();
        JsonNode body = objectMapper.readTree(response.getResponse().getContentAsString());
        long id = usuarioRepository.findByEmail(email).orElseThrow().getId();
        return new UserSession(id, email, body.get("token").asText());
    }

    private void salvarQuestionario(UserSession adotante, boolean temQuintal, boolean janelasComTela)
            throws Exception {
        mockMvc.perform(post(BASE_URL + "/questionarios")
                        .header("Authorization", bearer(adotante.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "tipoMoradia": "CASA",
                                  "temQuintal": %s,
                                  "janelasComTela": %s,
                                  "outrosAnimais": "Nenhum",
                                  "horasForaDeCasa": 8
                                }
                                """.formatted(temQuintal, janelasComTela)))
                .andExpect(status().isOk());
    }

    private long criarAnimalDisponivel(
            UserSession voluntario,
            String nome,
            String especie,
            String porte,
            String sexo,
            int idade) throws Exception {
        MvcResult response = mockMvc.perform(post(BASE_URL + "/animais")
                        .header("Authorization", bearer(voluntario.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(
                                new AnimalBody(nome, especie, porte, sexo, idade))))
                .andExpect(status().isCreated())
                .andReturn();
        long animalId = jsonLong(response, "id");
        registrarCuidado(animalId, voluntario, "VACINA");
        registrarCuidado(animalId, voluntario, "CASTRACAO");
        mockMvc.perform(put(BASE_URL + "/animais/" + animalId + "/disponivel")
                        .header("Authorization", bearer(voluntario.token())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("DISPONIVEL"));
        return animalId;
    }

    private void registrarCuidado(long animalId, UserSession voluntario, String tipo) throws Exception {
        mockMvc.perform(post(BASE_URL + "/animais/" + animalId + "/cuidados")
                        .header("Authorization", bearer(voluntario.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "tipo": "%s",
                                  "dataRealizacao": "2026-10-25",
                                  "descricao": "Cuidado registrado no teste"
                                }
                                """.formatted(tipo)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.tipo").value(tipo));
    }

    private long criarCandidatura(UserSession adotante, long animalId) throws Exception {
        MvcResult response = mockMvc.perform(post(BASE_URL + "/candidaturas")
                        .header("Authorization", bearer(adotante.token()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"animalId\":" + animalId + "}"))
                .andExpect(status().isCreated())
                .andReturn();
        return jsonLong(response, "id");
    }

    private long jsonLong(MvcResult response, String field) throws Exception {
        return objectMapper.readTree(response.getResponse().getContentAsString())
                .get(field).asLong();
    }

    private String bearer(String token) {
        return "Bearer " + token;
    }

    private record UserSession(long id, String email, String token) {
    }

    private record LoginBody(String email, String senha) {
    }

    private record AnimalBody(
            String nome,
            String especie,
            String porte,
            String sexo,
            int idadeEstimada) {
    }
}
