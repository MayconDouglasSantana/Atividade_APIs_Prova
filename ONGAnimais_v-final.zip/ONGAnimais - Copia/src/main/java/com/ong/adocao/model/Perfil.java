package com.ong.adocao.model;

public enum Perfil {
    ADOTANTE,
    VOLUNTARIO,
    COORDENADOR
}
