package com.ong.adocao.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ong.adocao.dto.AuthResponseDTO;
import com.ong.adocao.dto.LoginRequestDTO;
import com.ong.adocao.security.JwtUtil;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;
    private final long expirationSeconds;

    public AuthController(
            AuthenticationManager authenticationManager,
            JwtUtil jwtUtil,
            @Value("${ong.adocao.jwt.expiration-seconds:3600}") long expirationSeconds) {
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
        this.expirationSeconds = expirationSeconds;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequestDTO dto) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(dto.getEmail(), dto.getSenha()));
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            GrantedAuthority authority = userDetails.getAuthorities().stream()
                    .filter(item -> item instanceof SimpleGrantedAuthority)
                    .findFirst()
                    .orElseThrow(() -> new BadCredentialsException("Perfil de usuário inválido."));
            AuthResponseDTO response = new AuthResponseDTO(
                    jwtUtil.gerarToken(userDetails.getUsername(), authority.getAuthority()),
                    "Bearer",
                    expirationSeconds);
            return ResponseEntity.ok(response);
        } catch (BadCredentialsException exception) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new LoginErrorDTO("E-mail ou senha inválidos."));
        }
    }

    public record LoginErrorDTO(String message) {
    }
}
