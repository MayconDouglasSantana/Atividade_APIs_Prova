package com.ong.adocao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ong.adocao.model.CuidadoSaude;
import com.ong.adocao.model.TipoCuidado;

public interface CuidadoSaudeRepository extends JpaRepository<CuidadoSaude, Long> {

    List<CuidadoSaude> findByAnimalId(Long animalId);

    boolean existsByAnimalIdAndTipo(Long animalId, TipoCuidado tipo);
}
