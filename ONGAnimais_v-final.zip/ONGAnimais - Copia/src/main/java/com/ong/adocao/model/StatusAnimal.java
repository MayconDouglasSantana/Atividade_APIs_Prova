package com.ong.adocao.model;

public enum StatusAnimal {
    EM_TRATAMENTO,
    DISPONIVEL,
    EM_PROCESSO_DE_ADOCAO,
    ADOTADO
}
