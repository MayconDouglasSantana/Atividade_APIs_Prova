package com.ong.adocao.dto;

import java.time.LocalDate;

import com.ong.adocao.model.StatusCandidatura;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CandidaturaResponseDTO {

    private Long id;
    private Long animalId;
    private String nomeAnimal;
    private Long adotanteId;
    private StatusCandidatura status;
    private String motivoRecusa;
    private LocalDate dataCandidatura;
}
