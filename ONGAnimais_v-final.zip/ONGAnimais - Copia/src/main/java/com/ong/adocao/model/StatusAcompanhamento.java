package com.ong.adocao.model;

public enum StatusAcompanhamento {
    PENDENTE,
    REALIZADO,
    ATRASADO,
    CANCELADO
}
