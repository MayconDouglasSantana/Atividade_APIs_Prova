package com.ong.adocao.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.ong.adocao.model.Perfil;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.UsuarioRepository;

@Component
@Profile("demo")
public class DemoUserInitializer implements ApplicationRunner {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final String voluntarioEmail;
    private final String voluntarioSenha;
    private final String coordenadorEmail;
    private final String coordenadorSenha;

    public DemoUserInitializer(
            UsuarioRepository usuarioRepository,
            PasswordEncoder passwordEncoder,
            @Value("${ong.adocao.demo.voluntario.email:voluntario@ong.local}") String voluntarioEmail,
            @Value("${ong.adocao.demo.voluntario.senha:Voluntario123!}") String voluntarioSenha,
            @Value("${ong.adocao.demo.coordenador.email:coordenador@ong.local}") String coordenadorEmail,
            @Value("${ong.adocao.demo.coordenador.senha:Coordenador123!}") String coordenadorSenha) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
        this.voluntarioEmail = voluntarioEmail;
        this.voluntarioSenha = voluntarioSenha;
        this.coordenadorEmail = coordenadorEmail;
        this.coordenadorSenha = coordenadorSenha;
    }

    @Override
    public void run(ApplicationArguments args) {
        criarUsuarioSeAusente(
                "Voluntário de demonstração",
                "00000000001",
                voluntarioEmail,
                voluntarioSenha,
                Perfil.VOLUNTARIO);
        criarUsuarioSeAusente(
                "Coordenador de demonstração",
                "00000000002",
                coordenadorEmail,
                coordenadorSenha,
                Perfil.COORDENADOR);
    }

    private void criarUsuarioSeAusente(
            String nome,
            String cpf,
            String email,
            String senha,
            Perfil perfil) {
        Usuario existente = usuarioRepository.findByEmail(email).orElse(null);
        if (existente != null) {
            if (existente.getPerfil() != perfil) {
                throw new IllegalStateException(
                        "O e-mail configurado para " + perfil + " já pertence a outro perfil.");
            }
            return;
        }

        Usuario usuario = new Usuario();
        usuario.setNome(nome);
        usuario.setCpf(cpf);
        usuario.setEmail(email);
        usuario.setSenha(passwordEncoder.encode(senha));
        usuario.setPerfil(perfil);
        usuarioRepository.save(usuario);
    }
}
