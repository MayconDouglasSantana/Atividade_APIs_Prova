package com.ong.adocao.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ong.adocao.model.QuestionarioPerfil;

public interface QuestionarioPerfilRepository extends JpaRepository<QuestionarioPerfil, Long> {

    Optional<QuestionarioPerfil> findByUsuarioId(Long usuarioId);
}
