package com.ong.adocao.security;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.JwtEncoderParameters;
import org.springframework.security.oauth2.jwt.JwsHeader;
import org.springframework.stereotype.Component;

@Component
public class JwtUtil {

    private final JwtEncoder jwtEncoder;
    private final long expirationSeconds;

    public JwtUtil(
            JwtEncoder jwtEncoder,
            @Value("${ong.adocao.jwt.expiration-seconds:3600}") long expirationSeconds) {
        this.jwtEncoder = jwtEncoder;
        this.expirationSeconds = expirationSeconds;
    }

    public String gerarToken(String email, String perfil) {
        if (perfil == null || !perfil.matches("ROLE_(ADOTANTE|VOLUNTARIO|COORDENADOR)")) {
            throw new IllegalArgumentException("Perfil de autenticação inválido.");
        }

        Instant agora = Instant.now();
        JwtClaimsSet claims = JwtClaimsSet.builder()
                .issuer("https://ong-adocao.local")
                .issuedAt(agora)
                .expiresAt(agora.plusSeconds(expirationSeconds))
                .subject(email)
                .claim("perfil", perfil)
                .build();

        JwsHeader header = JwsHeader.with(MacAlgorithm.HS256).build();
        return jwtEncoder.encode(JwtEncoderParameters.from(header, claims)).getTokenValue();
    }
}
