package com.ong.adocao.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ong.adocao.exception.RegraNegocioException;
import com.ong.adocao.model.Acompanhamento;
import com.ong.adocao.model.Animal;
import com.ong.adocao.model.Candidatura;
import com.ong.adocao.model.Perfil;
import com.ong.adocao.model.RecomendacaoTriagem;
import com.ong.adocao.model.StatusAcompanhamento;
import com.ong.adocao.model.StatusAnimal;
import com.ong.adocao.model.StatusCandidatura;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.AcompanhamentoRepository;
import com.ong.adocao.repository.AnimalRepository;
import com.ong.adocao.repository.CandidaturaRepository;
import com.ong.adocao.repository.UsuarioRepository;

@Service
public class AdocaoService {

    private static final String MOTIVO_OUTRO_CANDIDATO = "Animal adotado por outro candidato";

    private final CandidaturaRepository candidaturaRepository;
    private final AnimalRepository animalRepository;
    private final UsuarioRepository usuarioRepository;
    private final AcompanhamentoRepository acompanhamentoRepository;

    public AdocaoService(
            CandidaturaRepository candidaturaRepository,
            AnimalRepository animalRepository,
            UsuarioRepository usuarioRepository,
            AcompanhamentoRepository acompanhamentoRepository) {
        this.candidaturaRepository = candidaturaRepository;
        this.animalRepository = animalRepository;
        this.usuarioRepository = usuarioRepository;
        this.acompanhamentoRepository = acompanhamentoRepository;
    }

    @Transactional
    public void aprovarAdocao(Long candidaturaId, Long coordenadorId) {
        Usuario coordenador = usuarioRepository.findById(coordenadorId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Coordenador não encontrado.",
                        HttpStatus.NOT_FOUND));
        if (coordenador.getPerfil() != Perfil.COORDENADOR) {
            throw new RegraNegocioException("Somente um coordenador pode aprovar uma adoção.");
        }

        Candidatura candidatura = candidaturaRepository.findById(candidaturaId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Candidatura não encontrada.",
                        HttpStatus.NOT_FOUND));
        if (candidatura.getStatus() != StatusCandidatura.EM_ANALISE) {
            throw new RegraNegocioException("Somente candidaturas em análise podem ser aprovadas.");
        }
        if (candidatura.getRecomendacao() != RecomendacaoTriagem.APROVAR) {
            throw new RegraNegocioException("A candidatura precisa de recomendação favorável na triagem.");
        }

        Animal animal = animalRepository.findByIdForUpdate(candidatura.getAnimal().getId())
                .orElseThrow(() -> new RegraNegocioException(
                        "Animal não encontrado.",
                        HttpStatus.NOT_FOUND));
        candidatura.setAnimal(animal);
        if (animal.getStatus() != StatusAnimal.EM_PROCESSO_DE_ADOCAO) {
            throw new RegraNegocioException("O animal não está em processo de adoção.");
        }

        LocalDate dataAprovacao = LocalDate.now();
        candidatura.setStatus(StatusCandidatura.APROVADA);
        candidatura.setDataAprovacao(dataAprovacao);
        candidatura.setCoordenadorAprovacao(coordenador);
        candidaturaRepository.save(candidatura);

        List<Candidatura> demaisCandidaturas = candidaturaRepository.findByAnimalIdAndStatus(
                animal.getId(),
                StatusCandidatura.EM_ANALISE);
        for (Candidatura outra : demaisCandidaturas) {
            if (!outra.getId().equals(candidatura.getId())) {
                outra.setStatus(StatusCandidatura.RECUSADA);
                outra.setMotivoRecusa(MOTIVO_OUTRO_CANDIDATO);
            }
        }
        candidaturaRepository.saveAll(demaisCandidaturas);

        animal.setStatus(StatusAnimal.ADOTADO);
        animalRepository.save(animal);

        List<Acompanhamento> acompanhamentos = new ArrayList<>();
        for (int dias : List.of(30, 90, 180)) {
            Acompanhamento acompanhamento = new Acompanhamento();
            acompanhamento.setAnimal(animal);
            acompanhamento.setAdotante(candidatura.getAdotante());
            acompanhamento.setDataPrevista(dataAprovacao.plusDays(dias));
            acompanhamento.setStatus(StatusAcompanhamento.PENDENTE);
            acompanhamentos.add(acompanhamento);
        }
        acompanhamentoRepository.saveAll(acompanhamentos);
    }
}
