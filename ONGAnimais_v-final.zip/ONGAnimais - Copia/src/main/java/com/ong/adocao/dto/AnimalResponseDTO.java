package com.ong.adocao.dto;

import java.time.LocalDate;

import com.ong.adocao.model.StatusAnimal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AnimalResponseDTO {

    private Long id;
    private String nome;
    private String especie;
    private String porte;
    private String sexo;
    private Integer idadeEstimada;
    private String temperamento;
    private String fotoUrl;
    private LocalDate dataEntrada;
    private StatusAnimal status;
}
