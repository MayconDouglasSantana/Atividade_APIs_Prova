package ifsp.apis.ONGAnimais;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;

import com.ong.adocao.model.Perfil;
import com.ong.adocao.model.Animal;
import com.ong.adocao.model.QuestionarioPerfil;
import com.ong.adocao.model.StatusAnimal;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.AnimalRepository;
import com.ong.adocao.repository.QuestionarioPerfilRepository;
import com.ong.adocao.repository.UsuarioRepository;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("demo")
class OngAnimaisApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Autowired
	private AnimalRepository animalRepository;

	@Autowired
	private QuestionarioPerfilRepository questionarioPerfilRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Test
	void contextLoads() {
	}

	@Test
	void inicializaContasDeDemonstracaoParaVoluntarioECoordenador() {
		Usuario voluntario = usuarioRepository.findByEmail("voluntario@ong.local").orElseThrow();
		Usuario coordenador = usuarioRepository.findByEmail("coordenador@ong.local").orElseThrow();

		assertEquals(Perfil.VOLUNTARIO, voluntario.getPerfil());
		assertEquals(Perfil.COORDENADOR, coordenador.getPerfil());
		assertTrue(passwordEncoder.matches("Voluntario123!", voluntario.getSenha()));
		assertTrue(passwordEncoder.matches("Coordenador123!", coordenador.getSenha()));
	}

	@Test
	void listaDeAnimaisDisponiveisPodeSerAcessadaSemAutenticacao() throws Exception {
		mockMvc.perform(get("/api/animais/disponiveis"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.content").isArray());
	}

	@Test
	void candidaturaUsaBloqueiosDeBancoEBuscaPublicaFiltraPorFaixaEtaria() throws Exception {
		String sufixo = java.util.UUID.randomUUID().toString();
		Usuario adotante = new Usuario();
		adotante.setNome("Adotante de fluxo");
		adotante.setCpf(sufixo);
		adotante.setEmail(sufixo + "@example.com");
		adotante.setSenha(passwordEncoder.encode("senha-teste-123"));
		adotante.setPerfil(Perfil.ADOTANTE);
		adotante = usuarioRepository.save(adotante);

		QuestionarioPerfil questionario = new QuestionarioPerfil();
		questionario.setUsuario(adotante);
		questionario.setJanelasComTela(true);
		questionarioPerfilRepository.save(questionario);

		Animal animal = new Animal();
		animal.setNome("Animal de teste " + sufixo);
		animal.setEspecie("Gato de teste " + sufixo);
		animal.setPorte("Pequeno");
		animal.setSexo("Macho");
		animal.setIdadeEstimada(4);
		animal.setStatus(StatusAnimal.DISPONIVEL);
		animal.setDataEntrada(java.time.LocalDate.now());
		animal = animalRepository.save(animal);

		Animal disponivelParaFiltro = new Animal();
		disponivelParaFiltro.setNome("Animal para filtro " + sufixo);
		disponivelParaFiltro.setEspecie(animal.getEspecie());
		disponivelParaFiltro.setPorte("Pequeno");
		disponivelParaFiltro.setSexo("Femea");
		disponivelParaFiltro.setIdadeEstimada(4);
		disponivelParaFiltro.setStatus(StatusAnimal.DISPONIVEL);
		disponivelParaFiltro.setDataEntrada(java.time.LocalDate.now());
		animalRepository.save(disponivelParaFiltro);

		String token = obterToken(adotante.getEmail(), "senha-teste-123");
		mockMvc.perform(post("/api/candidaturas")
						.header("Authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"animalId\":" + animal.getId() + "}"))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.status").value("EM_ANALISE"));

		mockMvc.perform(get("/api/animais/disponiveis")
						.param("especie", animal.getEspecie())
						.param("idadeMinima", "4")
						.param("idadeMaxima", "4"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.totalElements").value(1))
				.andExpect(jsonPath("$.content[0].nome").value(disponivelParaFiltro.getNome()));
	}

	@Test
	void loginGeraJwtEPermiteAcessoAutenticado() throws Exception {
		String sufixo = java.util.UUID.randomUUID().toString();
		Usuario usuario = new Usuario();
		usuario.setNome("Adotante de teste");
		usuario.setCpf(sufixo);
		usuario.setEmail(sufixo + "@example.com");
		usuario.setSenha(passwordEncoder.encode("senha-teste-123"));
		usuario.setPerfil(Perfil.ADOTANTE);
		usuarioRepository.save(usuario);

		String respostaLogin = mockMvc.perform(post("/api/auth/login")
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"email\":\"" + usuario.getEmail()
								+ "\",\"senha\":\"senha-teste-123\"}"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.tipo").value("Bearer"))
				.andReturn()
				.getResponse()
				.getContentAsString();
		String token = respostaLogin.replaceAll(".*\\\"token\\\":\\\"([^\\\"]+)\\\".*", "$1");

		mockMvc.perform(get("/api/candidaturas/minhas")
						.header("Authorization", "Bearer " + token))
				.andExpect(status().isOk());
		mockMvc.perform(post("/api/animais/1/devolucao")
						.header("Authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"adotanteId\":" + usuario.getId() + "}"))
				.andExpect(status().isForbidden());
	}

	@Test
	void endpointDeCandidaturasExigeAutenticacao() throws Exception {
		mockMvc.perform(get("/api/candidaturas/minhas?adotanteId=1"))
				.andExpect(status().isUnauthorized())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON));
	}

	@Test
	void loginPublicoRetorna401ParaCredenciaisInvalidas() throws Exception {
		mockMvc.perform(post("/api/auth/login")
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"email\":\"inexistente@example.com\",\"senha\":\"senha-incorreta\"}"))
				.andExpect(status().isUnauthorized())
				.andExpect(jsonPath("$.message").value("E-mail ou senha inválidos."));
	}

	@Test
	void coordenadorPodeAcessarAprovacaoERelatoriosMasVoluntarioNaoPodeAprovar() throws Exception {
		String tokenCoordenador = criarToken(Perfil.COORDENADOR);
		String tokenVoluntario = criarToken(Perfil.VOLUNTARIO);

		mockMvc.perform(post("/api/candidaturas/999999/aprovar")
						.header("Authorization", "Bearer " + tokenCoordenador))
				.andExpect(status().isNotFound());
		mockMvc.perform(post("/api/candidaturas/999999/aprovar")
						.header("Authorization", "Bearer " + tokenVoluntario))
				.andExpect(status().isForbidden());
		mockMvc.perform(get("/api/relatorios/adocoes-por-mes")
						.header("Authorization", "Bearer " + tokenCoordenador))
				.andExpect(status().isOk());
		mockMvc.perform(get("/api/relatorios/adocoes-por-mes")
						.header("Authorization", "Bearer " + tokenVoluntario))
				.andExpect(status().isForbidden());
		mockMvc.perform(post("/api/animais")
						.header("Authorization", "Bearer " + tokenCoordenador)
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"nome\":\"Rex\",\"especie\":\"Cachorro\",\"porte\":\"Medio\","
								+ "\"sexo\":\"Macho\",\"idadeEstimada\":3}"))
				.andExpect(status().isForbidden());
		mockMvc.perform(post("/api/candidaturas/999999/triagem")
						.header("Authorization", "Bearer " + tokenCoordenador)
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"agendaVisita\":\"2026-11-01T14:00:00\","
								+ "\"recomendacao\":\"APROVAR\"}"))
				.andExpect(status().isForbidden());
	}

	@Test
	void voluntarioPodeRegistrarAcompanhamentoECoordenadorNaoPode() throws Exception {
		String tokenVoluntario = criarToken(Perfil.VOLUNTARIO);
		String tokenCoordenador = criarToken(Perfil.COORDENADOR);

		mockMvc.perform(post("/api/acompanhamentos/999999/visita")
						.header("Authorization", "Bearer " + tokenVoluntario)
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"resultado\":\"Visita realizada\"}"))
				.andExpect(status().isNotFound());
		mockMvc.perform(post("/api/acompanhamentos/999999/visita")
						.header("Authorization", "Bearer " + tokenCoordenador)
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"resultado\":\"Visita realizada\"}"))
				.andExpect(status().isForbidden());
	}

	private String criarToken(Perfil perfil) throws Exception {
		String sufixo = java.util.UUID.randomUUID().toString();
		Usuario usuario = new Usuario();
		usuario.setNome("Usuário de teste");
		usuario.setCpf(sufixo);
		usuario.setEmail(sufixo + "@example.com");
		usuario.setSenha(passwordEncoder.encode("senha-teste-123"));
		usuario.setPerfil(perfil);
		usuarioRepository.save(usuario);

		return obterToken(usuario.getEmail(), "senha-teste-123");
	}

	private String obterToken(String email, String senha) throws Exception {
		String respostaLogin = mockMvc.perform(post("/api/auth/login")
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"email\":\"" + email + "\",\"senha\":\"" + senha + "\"}"))
				.andExpect(status().isOk())
				.andReturn()
				.getResponse()
				.getContentAsString();
		return respostaLogin.replaceAll(".*\\\"token\\\":\\\"([^\\\"]+)\\\".*", "$1");
	}

}
