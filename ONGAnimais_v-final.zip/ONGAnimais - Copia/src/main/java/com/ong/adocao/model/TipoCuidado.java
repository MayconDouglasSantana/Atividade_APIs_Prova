package com.ong.adocao.model;

public enum TipoCuidado {
    VACINA,
    VERMIFUGACAO,
    CASTRACAO
}
