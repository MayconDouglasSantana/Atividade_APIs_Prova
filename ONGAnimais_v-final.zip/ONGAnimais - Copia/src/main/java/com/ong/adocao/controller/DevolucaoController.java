package com.ong.adocao.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ong.adocao.dto.DevolucaoRequestDTO;
import com.ong.adocao.service.DevolucaoService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/animais")
public class DevolucaoController {

    private final DevolucaoService devolucaoService;

    public DevolucaoController(DevolucaoService devolucaoService) {
        this.devolucaoService = devolucaoService;
    }

    @PostMapping("/{id}/devolucao")
    public ResponseEntity<Void> registrarDevolucao(
            @PathVariable Long id,
            @Valid @RequestBody DevolucaoRequestDTO dto) {
        devolucaoService.registrarDevolucao(id, dto.getAdotanteId());
        return ResponseEntity.noContent().build();
    }
}
