package com.ong.adocao.service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ong.adocao.exception.RegraNegocioException;
import com.ong.adocao.model.Acompanhamento;
import com.ong.adocao.model.Perfil;
import com.ong.adocao.model.StatusAcompanhamento;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.AcompanhamentoRepository;
import com.ong.adocao.repository.UsuarioRepository;

@Service
public class AcompanhamentoService {

    private final AcompanhamentoRepository acompanhamentoRepository;
    private final UsuarioRepository usuarioRepository;

    public AcompanhamentoService(
            AcompanhamentoRepository acompanhamentoRepository,
            UsuarioRepository usuarioRepository) {
        this.acompanhamentoRepository = acompanhamentoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @Transactional
    public Acompanhamento registrarVisita(Long acompanhamentoId, Long voluntarioId, String resultado) {
        Acompanhamento acompanhamento = acompanhamentoRepository.findById(acompanhamentoId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Acompanhamento não encontrado.",
                        HttpStatus.NOT_FOUND));
        Usuario voluntario = usuarioRepository.findById(voluntarioId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Voluntário não encontrado.",
                        HttpStatus.NOT_FOUND));
        if (voluntario.getPerfil() != Perfil.VOLUNTARIO) {
            throw new RegraNegocioException("Somente um voluntário pode registrar uma visita.");
        }

        if (acompanhamento.getStatus() == StatusAcompanhamento.CANCELADO) {
            throw new RegraNegocioException("Não é possível registrar visita em acompanhamento cancelado.");
        }
        if (resultado == null || resultado.isBlank()) {
            throw new RegraNegocioException("Informe o resultado da visita.");
        }

        acompanhamento.setResultado(resultado);
        acompanhamento.setStatus(StatusAcompanhamento.REALIZADO);
        acompanhamento.setVoluntario(voluntario);
        return acompanhamentoRepository.save(acompanhamento);
    }

    @Transactional(readOnly = true)
    public List<Acompanhamento> buscarPorAnimal(Long animalId) {
        return acompanhamentoRepository.findByAnimalId(animalId);
    }
}
