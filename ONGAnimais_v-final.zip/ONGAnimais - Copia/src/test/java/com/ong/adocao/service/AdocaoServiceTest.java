package com.ong.adocao.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ong.adocao.model.Acompanhamento;
import com.ong.adocao.model.Animal;
import com.ong.adocao.model.Candidatura;
import com.ong.adocao.model.Perfil;
import com.ong.adocao.model.RecomendacaoTriagem;
import com.ong.adocao.model.StatusAcompanhamento;
import com.ong.adocao.model.StatusAnimal;
import com.ong.adocao.model.StatusCandidatura;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.AcompanhamentoRepository;
import com.ong.adocao.repository.AnimalRepository;
import com.ong.adocao.repository.CandidaturaRepository;
import com.ong.adocao.repository.UsuarioRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class AdocaoServiceTest {

    private CandidaturaRepository candidaturaRepository;
    private AnimalRepository animalRepository;
    private UsuarioRepository usuarioRepository;
    private AcompanhamentoRepository acompanhamentoRepository;
    private AdocaoService adocaoService;

    @BeforeEach
    void setUp() {
        candidaturaRepository = mock(CandidaturaRepository.class);
        animalRepository = mock(AnimalRepository.class);
        usuarioRepository = mock(UsuarioRepository.class);
        acompanhamentoRepository = mock(AcompanhamentoRepository.class);
        adocaoService = new AdocaoService(
                candidaturaRepository,
                animalRepository,
                usuarioRepository,
                acompanhamentoRepository);
    }

    @Test
    void aprovaAdocaoRecusaOutrasCandidaturasEGeraTresAcompanhamentos() {
        Usuario coordenador = new Usuario();
        coordenador.setId(10L);
        coordenador.setPerfil(Perfil.COORDENADOR);
        Usuario adotante = new Usuario();
        adotante.setId(20L);
        Animal animal = new Animal();
        animal.setId(30L);
        animal.setStatus(StatusAnimal.EM_PROCESSO_DE_ADOCAO);

        Candidatura aprovada = new Candidatura();
        aprovada.setId(40L);
        aprovada.setAdotante(adotante);
        aprovada.setAnimal(animal);
        aprovada.setStatus(StatusCandidatura.EM_ANALISE);
        aprovada.setRecomendacao(RecomendacaoTriagem.APROVAR);

        Candidatura recusada = new Candidatura();
        recusada.setId(41L);
        recusada.setAnimal(animal);
        recusada.setStatus(StatusCandidatura.EM_ANALISE);

        when(usuarioRepository.findById(10L)).thenReturn(Optional.of(coordenador));
        when(candidaturaRepository.findById(40L)).thenReturn(Optional.of(aprovada));
        when(animalRepository.findByIdForUpdate(30L)).thenReturn(Optional.of(animal));
        when(candidaturaRepository.findByAnimalIdAndStatus(30L, StatusCandidatura.EM_ANALISE))
                .thenReturn(List.of(aprovada, recusada));

        adocaoService.aprovarAdocao(40L, 10L);

        assertEquals(StatusCandidatura.APROVADA, aprovada.getStatus());
        assertEquals(LocalDate.now(), aprovada.getDataAprovacao());
        assertEquals(coordenador, aprovada.getCoordenadorAprovacao());
        assertEquals(StatusCandidatura.RECUSADA, recusada.getStatus());
        assertEquals("Animal adotado por outro candidato", recusada.getMotivoRecusa());
        assertEquals(StatusAnimal.ADOTADO, animal.getStatus());

        var captor = org.mockito.ArgumentCaptor.forClass(List.class);
        verify(acompanhamentoRepository).saveAll(captor.capture());
        @SuppressWarnings("unchecked")
        List<Acompanhamento> acompanhamentos = (List<Acompanhamento>) captor.getValue();
        assertEquals(3, acompanhamentos.size());
        assertEquals(
                List.of(30L, 90L, 180L),
                acompanhamentos.stream()
                        .map(item -> java.time.temporal.ChronoUnit.DAYS.between(
                                LocalDate.now(),
                                item.getDataPrevista()))
                        .toList());
        assertEquals(StatusAcompanhamento.PENDENTE, acompanhamentos.get(0).getStatus());
        assertEquals(animal, acompanhamentos.get(0).getAnimal());
        assertEquals(adotante, acompanhamentos.get(0).getAdotante());
        verify(animalRepository).save(animal);
    }
}
