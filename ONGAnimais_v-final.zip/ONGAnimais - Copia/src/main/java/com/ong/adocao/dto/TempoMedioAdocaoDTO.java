package com.ong.adocao.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TempoMedioAdocaoDTO {

    private String especie;
    private String porte;
    private long totalAdocoes;
    private Double mediaDias;
}
