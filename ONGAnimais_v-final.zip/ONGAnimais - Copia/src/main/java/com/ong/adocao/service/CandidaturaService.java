package com.ong.adocao.service;

import java.text.Normalizer;
import java.time.LocalDate;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ong.adocao.dto.CandidaturaResponseDTO;
import com.ong.adocao.dto.TriagemDTO;
import com.ong.adocao.exception.RegraNegocioException;
import com.ong.adocao.model.Animal;
import com.ong.adocao.model.Candidatura;
import com.ong.adocao.model.Perfil;
import com.ong.adocao.model.QuestionarioPerfil;
import com.ong.adocao.model.RecomendacaoTriagem;
import com.ong.adocao.model.StatusAnimal;
import com.ong.adocao.model.StatusCandidatura;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.AnimalRepository;
import com.ong.adocao.repository.CandidaturaRepository;
import com.ong.adocao.repository.QuestionarioPerfilRepository;
import com.ong.adocao.repository.UsuarioRepository;

@Service
public class CandidaturaService {

    private static final Pattern ACENTOS = Pattern.compile("\\p{M}");

    private final CandidaturaRepository candidaturaRepository;
    private final UsuarioRepository usuarioRepository;
    private final AnimalRepository animalRepository;
    private final QuestionarioPerfilRepository questionarioPerfilRepository;

    public CandidaturaService(
            CandidaturaRepository candidaturaRepository,
            UsuarioRepository usuarioRepository,
            AnimalRepository animalRepository,
            QuestionarioPerfilRepository questionarioPerfilRepository) {
        this.candidaturaRepository = candidaturaRepository;
        this.usuarioRepository = usuarioRepository;
        this.animalRepository = animalRepository;
        this.questionarioPerfilRepository = questionarioPerfilRepository;
    }

    @Transactional
    public CandidaturaResponseDTO candidatar(Long adotanteId, Long animalId) {
        Usuario adotante = usuarioRepository.findByIdForUpdate(adotanteId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Adotante não encontrado.",
                        HttpStatus.NOT_FOUND));
        if (adotante.getPerfil() != Perfil.ADOTANTE) {
            throw new RegraNegocioException("Somente adotantes podem registrar candidaturas.");
        }
        if (adotante.getBloqueadoAte() != null
                && !adotante.getBloqueadoAte().isBefore(LocalDate.now())) {
            throw new RegraNegocioException(
                    "Você está bloqueado para novas candidaturas até " + adotante.getBloqueadoAte() + ".");
        }

        QuestionarioPerfil questionario = questionarioPerfilRepository.findByUsuarioId(adotanteId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Preencha o questionário de perfil antes de se candidatar."));

        long candidaturasEmAnalise = candidaturaRepository.countByAdotanteIdAndStatus(
                adotanteId,
                StatusCandidatura.EM_ANALISE);
        if (candidaturasEmAnalise >= 2) {
            throw new RegraNegocioException(
                    "Você já possui o limite de 2 candidaturas em análise.");
        }

        Animal animal = animalRepository.findByIdForUpdate(animalId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Animal não encontrado.",
                        HttpStatus.NOT_FOUND));

        if (animal.getStatus() != StatusAnimal.DISPONIVEL
                && animal.getStatus() != StatusAnimal.EM_PROCESSO_DE_ADOCAO) {
            throw new RegraNegocioException("Este animal não está disponível para candidaturas.");
        }

        Candidatura candidatura = new Candidatura();
        candidatura.setAdotante(adotante);
        candidatura.setAnimal(animal);
        candidatura.setDataCandidatura(LocalDate.now());

        String motivoPreTriagem = verificarPreTriagem(animal, questionario);
        if (motivoPreTriagem != null) {
            candidatura.setStatus(StatusCandidatura.RECUSADA);
            candidatura.setMotivoRecusa(motivoPreTriagem);
        } else {
            candidatura.setStatus(StatusCandidatura.EM_ANALISE);
            if (animal.getStatus() == StatusAnimal.DISPONIVEL) {
                animal.setStatus(StatusAnimal.EM_PROCESSO_DE_ADOCAO);
                animalRepository.save(animal);
            }
        }

        return toResponseDTO(candidaturaRepository.save(candidatura));
    }

    @Transactional(readOnly = true)
    public List<CandidaturaResponseDTO> buscarMinhas(Long adotanteId) {
        if (!usuarioRepository.existsById(adotanteId)) {
            throw new RegraNegocioException("Adotante não encontrado.", HttpStatus.NOT_FOUND);
        }

        return candidaturaRepository.findByAdotanteId(adotanteId)
                .stream()
                .map(this::toResponseDTO)
                .toList();
    }

    @Transactional
    public TriagemDTO avaliarTriagem(Long candidaturaId, TriagemDTO dto) {
        Candidatura candidatura = buscarCandidatura(candidaturaId);
        Animal animal = animalRepository.findByIdForUpdate(candidatura.getAnimal().getId())
                .orElseThrow(() -> new RegraNegocioException(
                        "Animal não encontrado.",
                        HttpStatus.NOT_FOUND));
        candidatura.setAnimal(animal);
        if (candidatura.getStatus() != StatusCandidatura.EM_ANALISE) {
            throw new RegraNegocioException(
                    "Somente candidaturas em análise podem receber triagem.");
        }

        if (dto.getRecomendacao() == RecomendacaoTriagem.RECUSAR
                && (dto.getMotivoRecusa() == null || dto.getMotivoRecusa().isBlank())) {
            throw new RegraNegocioException("Informe o motivo para recomendar a recusa.");
        }

        candidatura.setAgendaVisita(dto.getAgendaVisita());
        candidatura.setRecomendacao(dto.getRecomendacao());
        candidatura.setMotivoRecusa(
                dto.getRecomendacao() == RecomendacaoTriagem.RECUSAR
                        ? dto.getMotivoRecusa()
                        : null);
        if (dto.getRecomendacao() == RecomendacaoTriagem.RECUSAR) {
            candidatura.setStatus(StatusCandidatura.RECUSADA);
        }

        Candidatura salva = candidaturaRepository.save(candidatura);
        if (salva.getStatus() == StatusCandidatura.RECUSADA) {
            atualizarDisponibilidadeSeSemCandidaturasAtivas(salva.getAnimal());
        }
        return new TriagemDTO(
                salva.getAgendaVisita(),
                salva.getRecomendacao(),
                salva.getMotivoRecusa());
    }

    @Transactional
    public void cancelarCandidatura(Long candidaturaId, Long adotanteId) {
        Candidatura candidatura = candidaturaRepository.findByIdAndAdotanteId(candidaturaId, adotanteId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Candidatura não encontrada para este adotante.",
                        HttpStatus.NOT_FOUND));
        Animal animal = animalRepository.findByIdForUpdate(candidatura.getAnimal().getId())
                .orElseThrow(() -> new RegraNegocioException(
                        "Animal não encontrado.",
                        HttpStatus.NOT_FOUND));
        candidatura.setAnimal(animal);

        if (candidatura.getStatus() != StatusCandidatura.EM_ANALISE) {
            throw new RegraNegocioException("Somente candidaturas em análise podem ser canceladas.");
        }

        candidatura.setStatus(StatusCandidatura.CANCELADA);
        candidaturaRepository.saveAndFlush(candidatura);

        atualizarDisponibilidadeSeSemCandidaturasAtivas(animal);
    }

    private void atualizarDisponibilidadeSeSemCandidaturasAtivas(Animal animal) {
        List<Candidatura> candidaturasDoAnimal =
                candidaturaRepository.findByAnimalId(animal.getId());
        boolean todasEncerradas = candidaturasDoAnimal.stream()
                .allMatch(item -> item.getStatus() == StatusCandidatura.CANCELADA
                        || item.getStatus() == StatusCandidatura.RECUSADA);

        if (todasEncerradas && animal.getStatus() == StatusAnimal.EM_PROCESSO_DE_ADOCAO) {
            animal.setStatus(StatusAnimal.DISPONIVEL);
            animalRepository.save(animal);
        }
    }

    private Candidatura buscarCandidatura(Long candidaturaId) {
        return candidaturaRepository.findById(candidaturaId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Candidatura não encontrada.",
                        HttpStatus.NOT_FOUND));
    }

    private String verificarPreTriagem(Animal animal, QuestionarioPerfil questionario) {
        String especie = normalizar(animal.getEspecie());
        String porte = normalizar(animal.getPorte());

        if (("cao".equals(especie) || "cachorro".equals(especie))
                && "grande".equals(porte)
                && !questionario.isTemQuintal()) {
            return "Pré-triagem: é necessário ter quintal para se candidatar a um cão de porte grande.";
        }

        if ("gato".equals(especie) && !questionario.isJanelasComTela()) {
            return "Pré-triagem: é necessário ter telas nas janelas para se candidatar a um gato.";
        }

        return null;
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return "";
        }

        String semAcentos = ACENTOS.matcher(
                Normalizer.normalize(valor.trim().toLowerCase(), Normalizer.Form.NFD))
                .replaceAll("");
        return semAcentos;
    }

    private CandidaturaResponseDTO toResponseDTO(Candidatura candidatura) {
        return new CandidaturaResponseDTO(
                candidatura.getId(),
                candidatura.getAnimal().getId(),
                candidatura.getAnimal().getNome(),
                candidatura.getAdotante().getId(),
                candidatura.getStatus(),
                candidatura.getMotivoRecusa(),
                candidatura.getDataCandidatura());
    }
}
