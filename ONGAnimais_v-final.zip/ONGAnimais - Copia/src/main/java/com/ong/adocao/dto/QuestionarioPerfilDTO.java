package com.ong.adocao.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class QuestionarioPerfilDTO {

    private String tipoMoradia;
    private boolean temQuintal;
    private boolean janelasComTela;
    private String outrosAnimais;
    private Integer horasForaDeCasa;
}
