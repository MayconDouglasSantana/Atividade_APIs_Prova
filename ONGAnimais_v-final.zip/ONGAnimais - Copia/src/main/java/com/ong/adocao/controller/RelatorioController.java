package com.ong.adocao.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ong.adocao.dto.AdocoesPorMesDTO;
import com.ong.adocao.dto.AcompanhamentoAtrasadoDTO;
import com.ong.adocao.dto.TempoMedioAdocaoDTO;
import com.ong.adocao.service.RelatorioService;

@RestController
@RequestMapping("/api/relatorios")
public class RelatorioController {

    private final RelatorioService relatorioService;

    public RelatorioController(RelatorioService relatorioService) {
        this.relatorioService = relatorioService;
    }

    @GetMapping("/adocoes-por-mes")
    public ResponseEntity<List<AdocoesPorMesDTO>> adocoesPorMes() {
        return ResponseEntity.ok(relatorioService.adocoesPorMes());
    }

    @GetMapping("/tempo-medio-adocao")
    public ResponseEntity<List<TempoMedioAdocaoDTO>> tempoMedioAdocao() {
        return ResponseEntity.ok(relatorioService.tempoMedioAdocao());
    }

    @GetMapping("/acompanhamentos-atrasados")
    public ResponseEntity<List<AcompanhamentoAtrasadoDTO>> acompanhamentosAtrasados() {
        return ResponseEntity.ok(relatorioService.acompanhamentosAtrasados());
    }
}
