package com.ong.adocao.service;

import java.util.List;
import java.util.Optional;
import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ong.adocao.dto.CandidaturaResponseDTO;
import com.ong.adocao.dto.TriagemDTO;
import com.ong.adocao.exception.RegraNegocioException;
import com.ong.adocao.model.Animal;
import com.ong.adocao.model.Candidatura;
import com.ong.adocao.model.Perfil;
import com.ong.adocao.model.QuestionarioPerfil;
import com.ong.adocao.model.RecomendacaoTriagem;
import com.ong.adocao.model.StatusAnimal;
import com.ong.adocao.model.StatusCandidatura;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.AnimalRepository;
import com.ong.adocao.repository.CandidaturaRepository;
import com.ong.adocao.repository.QuestionarioPerfilRepository;
import com.ong.adocao.repository.UsuarioRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class CandidaturaServiceTest {

    private CandidaturaRepository candidaturaRepository;
    private UsuarioRepository usuarioRepository;
    private AnimalRepository animalRepository;
    private QuestionarioPerfilRepository questionarioPerfilRepository;
    private CandidaturaService candidaturaService;

    @BeforeEach
    void setUp() {
        candidaturaRepository = mock(CandidaturaRepository.class);
        usuarioRepository = mock(UsuarioRepository.class);
        animalRepository = mock(AnimalRepository.class);
        questionarioPerfilRepository = mock(QuestionarioPerfilRepository.class);
        candidaturaService = new CandidaturaService(
                candidaturaRepository,
                usuarioRepository,
                animalRepository,
                questionarioPerfilRepository);

        when(candidaturaRepository.save(any(Candidatura.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
    }

    @Test
    void recusaNaPreTriagemQuandoAdotanteNaoTemQuintalParaCaoGrande() {
        Usuario adotante = new Usuario();
        adotante.setId(1L);
        adotante.setPerfil(Perfil.ADOTANTE);
        QuestionarioPerfil questionario = new QuestionarioPerfil();
        Animal animal = new Animal();
        animal.setId(2L);
        animal.setNome("Rex");
        animal.setEspecie("Cachorro");
        animal.setPorte("Grande");
        animal.setStatus(StatusAnimal.DISPONIVEL);

        when(usuarioRepository.findByIdForUpdate(1L)).thenReturn(Optional.of(adotante));
        when(questionarioPerfilRepository.findByUsuarioId(1L)).thenReturn(Optional.of(questionario));
        when(candidaturaRepository.countByAdotanteIdAndStatus(1L, StatusCandidatura.EM_ANALISE))
                .thenReturn(0L);
        when(animalRepository.findByIdForUpdate(2L)).thenReturn(Optional.of(animal));

        CandidaturaResponseDTO resposta = candidaturaService.candidatar(1L, 2L);

        assertEquals(StatusCandidatura.RECUSADA, resposta.getStatus());
        assertEquals(StatusAnimal.DISPONIVEL, animal.getStatus());
        verify(animalRepository, never()).save(animal);
    }

    @Test
    void bloqueiaNovaCandidaturaQuandoAdotanteJaTemDuasEmAnalise() {
        Usuario adotante = new Usuario();
        adotante.setPerfil(Perfil.ADOTANTE);
        QuestionarioPerfil questionario = new QuestionarioPerfil();

        when(usuarioRepository.findByIdForUpdate(1L)).thenReturn(Optional.of(adotante));
        when(questionarioPerfilRepository.findByUsuarioId(1L)).thenReturn(Optional.of(questionario));
        when(candidaturaRepository.countByAdotanteIdAndStatus(1L, StatusCandidatura.EM_ANALISE))
                .thenReturn(2L);

        assertThrows(RegraNegocioException.class, () -> candidaturaService.candidatar(1L, 2L));
        verify(animalRepository, never()).findByIdForUpdate(2L);
    }

    @Test
    void primeiraCandidaturaAprovadaNaPreTriagemMoveAnimalParaProcessoDeAdocao() {
        Usuario adotante = new Usuario();
        adotante.setId(1L);
        adotante.setPerfil(Perfil.ADOTANTE);
        QuestionarioPerfil questionario = new QuestionarioPerfil();
        questionario.setTemQuintal(true);
        Animal animal = new Animal();
        animal.setId(2L);
        animal.setNome("Rex");
        animal.setStatus(StatusAnimal.DISPONIVEL);

        when(usuarioRepository.findByIdForUpdate(1L)).thenReturn(Optional.of(adotante));
        when(questionarioPerfilRepository.findByUsuarioId(1L)).thenReturn(Optional.of(questionario));
        when(candidaturaRepository.countByAdotanteIdAndStatus(1L, StatusCandidatura.EM_ANALISE))
                .thenReturn(0L);
        when(animalRepository.findByIdForUpdate(2L)).thenReturn(Optional.of(animal));

        CandidaturaResponseDTO resposta = candidaturaService.candidatar(1L, 2L);

        assertEquals(StatusCandidatura.EM_ANALISE, resposta.getStatus());
        assertEquals(StatusAnimal.EM_PROCESSO_DE_ADOCAO, animal.getStatus());
        verify(animalRepository).save(animal);
    }

    @Test
    void cancelarUltimaCandidaturaAtivaDevolveAnimalParaDisponivel() {
        Usuario adotante = new Usuario();
        adotante.setId(1L);
        adotante.setPerfil(Perfil.ADOTANTE);
        Animal animal = new Animal();
        animal.setId(2L);
        animal.setStatus(StatusAnimal.EM_PROCESSO_DE_ADOCAO);
        Candidatura candidatura = new Candidatura();
        candidatura.setId(3L);
        candidatura.setAdotante(adotante);
        candidatura.setAnimal(animal);
        candidatura.setStatus(StatusCandidatura.EM_ANALISE);

        when(candidaturaRepository.findByIdAndAdotanteId(3L, 1L))
                .thenReturn(Optional.of(candidatura));
        when(animalRepository.findByIdForUpdate(2L)).thenReturn(Optional.of(animal));
        when(candidaturaRepository.saveAndFlush(candidatura)).thenReturn(candidatura);
        when(candidaturaRepository.findByAnimalId(2L)).thenReturn(List.of(candidatura));

        candidaturaService.cancelarCandidatura(3L, 1L);

        assertEquals(StatusCandidatura.CANCELADA, candidatura.getStatus());
        assertEquals(StatusAnimal.DISPONIVEL, animal.getStatus());
        verify(animalRepository).save(animal);
    }

    @Test
    void candidaturaRecusadaNaTriagemEncerraEAnimalVoltaADisponivel() {
        Animal animal = new Animal();
        animal.setId(2L);
        animal.setStatus(StatusAnimal.EM_PROCESSO_DE_ADOCAO);
        Candidatura candidatura = new Candidatura();
        candidatura.setId(3L);
        candidatura.setAnimal(animal);
        candidatura.setStatus(StatusCandidatura.EM_ANALISE);
        when(candidaturaRepository.findById(3L)).thenReturn(Optional.of(candidatura));
        when(animalRepository.findByIdForUpdate(2L)).thenReturn(Optional.of(animal));
        when(candidaturaRepository.save(any(Candidatura.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
        when(candidaturaRepository.findByAnimalId(2L)).thenReturn(List.of(candidatura));

        TriagemDTO triagem = new TriagemDTO(
                LocalDateTime.now().plusDays(1),
                RecomendacaoTriagem.RECUSAR,
                "Moradia sem condições adequadas");

        candidaturaService.avaliarTriagem(3L, triagem);

        assertEquals(StatusCandidatura.RECUSADA, candidatura.getStatus());
        assertEquals(StatusAnimal.DISPONIVEL, animal.getStatus());
        verify(animalRepository).save(animal);
    }
}
