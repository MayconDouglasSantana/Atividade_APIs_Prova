package com.ong.adocao.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ong.adocao.dto.AcompanhamentoRequestDTO;
import com.ong.adocao.dto.AcompanhamentoResponseDTO;
import com.ong.adocao.exception.RegraNegocioException;
import com.ong.adocao.model.Acompanhamento;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.UsuarioRepository;
import com.ong.adocao.service.AcompanhamentoService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/acompanhamentos")
public class AcompanhamentoController {

    private final AcompanhamentoService acompanhamentoService;
    private final UsuarioRepository usuarioRepository;

    public AcompanhamentoController(
            AcompanhamentoService acompanhamentoService,
            UsuarioRepository usuarioRepository) {
        this.acompanhamentoService = acompanhamentoService;
        this.usuarioRepository = usuarioRepository;
    }

    @GetMapping("/animal/{animalId}")
    public ResponseEntity<List<AcompanhamentoResponseDTO>> buscarPorAnimal(@PathVariable Long animalId) {
        List<AcompanhamentoResponseDTO> acompanhamentos = acompanhamentoService.buscarPorAnimal(animalId)
                .stream()
                .map(this::toResponseDTO)
                .toList();
        return ResponseEntity.ok(acompanhamentos);
    }

    @PostMapping("/{id}/visita")
    public ResponseEntity<AcompanhamentoResponseDTO> registrarVisita(
            @PathVariable Long id,
            @AuthenticationPrincipal Jwt jwt,
            @Valid @RequestBody AcompanhamentoRequestDTO dto) {
        Usuario voluntario = usuarioRepository.findByEmail(jwt.getSubject())
                .orElseThrow(() -> new RegraNegocioException("Voluntário autenticado não encontrado."));
        Acompanhamento acompanhamento =
                acompanhamentoService.registrarVisita(id, voluntario.getId(), dto.getResultado());

        return ResponseEntity.ok(toResponseDTO(acompanhamento));
    }

    private AcompanhamentoResponseDTO toResponseDTO(Acompanhamento acompanhamento) {
        return new AcompanhamentoResponseDTO(
                acompanhamento.getId(),
                acompanhamento.getAnimal().getId(),
                acompanhamento.getAnimal().getNome(),
                acompanhamento.getAdotante().getId(),
                acompanhamento.getVoluntario() == null ? null : acompanhamento.getVoluntario().getId(),
                acompanhamento.getDataPrevista(),
                acompanhamento.getStatus(),
                acompanhamento.getResultado());
    }
}
