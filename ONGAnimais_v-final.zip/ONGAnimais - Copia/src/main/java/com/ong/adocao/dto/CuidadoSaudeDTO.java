package com.ong.adocao.dto;

import java.time.LocalDate;

import com.ong.adocao.model.TipoCuidado;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CuidadoSaudeDTO {

    private TipoCuidado tipo;
    private LocalDate dataRealizacao;
    private String descricao;
}
