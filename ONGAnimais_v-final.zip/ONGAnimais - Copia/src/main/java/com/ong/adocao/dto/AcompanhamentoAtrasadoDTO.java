package com.ong.adocao.dto;

import java.time.LocalDate;

import com.ong.adocao.model.StatusAcompanhamento;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AcompanhamentoAtrasadoDTO {

    private Long id;
    private Long animalId;
    private String nomeAnimal;
    private Long adotanteId;
    private String nomeAdotante;
    private LocalDate dataPrevista;
    private StatusAcompanhamento status;
}
