package ifsp.apis.ONGAnimais;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = {"ifsp.apis.ONGAnimais", "com.ong.adocao"})
@EntityScan(basePackages = "com.ong.adocao.model")
@EnableJpaRepositories(basePackages = "com.ong.adocao.repository")
public class OngAnimaisApplication {

	public static void main(String[] args) {
		SpringApplication.run(OngAnimaisApplication.class, args);
	}

}
