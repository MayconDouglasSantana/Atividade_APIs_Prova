package com.ong.adocao.service;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ong.adocao.dto.CuidadoSaudeDTO;
import com.ong.adocao.exception.RegraNegocioException;
import com.ong.adocao.model.Animal;
import com.ong.adocao.model.CuidadoSaude;
import com.ong.adocao.repository.AnimalRepository;
import com.ong.adocao.repository.CuidadoSaudeRepository;

@Service
public class CuidadoSaudeService {

    private final CuidadoSaudeRepository cuidadoSaudeRepository;
    private final AnimalRepository animalRepository;

    public CuidadoSaudeService(
            CuidadoSaudeRepository cuidadoSaudeRepository,
            AnimalRepository animalRepository) {
        this.cuidadoSaudeRepository = cuidadoSaudeRepository;
        this.animalRepository = animalRepository;
    }

    @Transactional
    public CuidadoSaudeDTO registrarCuidado(Long animalId, CuidadoSaudeDTO dto) {
        Animal animal = animalRepository.findById(animalId)
                .orElseThrow(() -> new RegraNegocioException(
                        "Animal não encontrado.",
                        HttpStatus.NOT_FOUND));

        CuidadoSaude cuidado = new CuidadoSaude();
        cuidado.setAnimal(animal);
        cuidado.setTipo(dto.getTipo());
        cuidado.setDataRealizacao(dto.getDataRealizacao());
        cuidado.setDescricao(dto.getDescricao());

        CuidadoSaude salvo = cuidadoSaudeRepository.save(cuidado);
        return new CuidadoSaudeDTO(
                salvo.getTipo(),
                salvo.getDataRealizacao(),
                salvo.getDescricao());
    }
}
