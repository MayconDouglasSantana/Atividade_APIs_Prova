package com.ong.adocao.dto;

import java.time.LocalDateTime;

import com.ong.adocao.model.RecomendacaoTriagem;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TriagemDTO {

    @NotNull
    private LocalDateTime agendaVisita;

    @NotNull
    private RecomendacaoTriagem recomendacao;

    private String motivoRecusa;
}
