package com.ong.adocao.dto;

import java.time.LocalDate;

import com.ong.adocao.model.StatusAcompanhamento;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AcompanhamentoResponseDTO {

    private Long id;
    private Long animalId;
    private String nomeAnimal;
    private Long adotanteId;
    private Long voluntarioId;
    private LocalDate dataPrevista;
    private StatusAcompanhamento status;
    private String resultado;
}
