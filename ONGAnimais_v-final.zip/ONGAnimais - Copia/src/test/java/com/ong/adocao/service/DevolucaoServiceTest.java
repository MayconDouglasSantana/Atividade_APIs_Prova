package com.ong.adocao.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ong.adocao.model.Acompanhamento;
import com.ong.adocao.model.Animal;
import com.ong.adocao.model.StatusAcompanhamento;
import com.ong.adocao.model.StatusAnimal;
import com.ong.adocao.model.StatusCandidatura;
import com.ong.adocao.model.Usuario;
import com.ong.adocao.repository.AcompanhamentoRepository;
import com.ong.adocao.repository.AnimalRepository;
import com.ong.adocao.repository.CandidaturaRepository;
import com.ong.adocao.repository.UsuarioRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class DevolucaoServiceTest {

    private AnimalRepository animalRepository;
    private UsuarioRepository usuarioRepository;
    private CandidaturaRepository candidaturaRepository;
    private AcompanhamentoRepository acompanhamentoRepository;
    private DevolucaoService devolucaoService;

    @BeforeEach
    void setUp() {
        animalRepository = mock(AnimalRepository.class);
        usuarioRepository = mock(UsuarioRepository.class);
        candidaturaRepository = mock(CandidaturaRepository.class);
        acompanhamentoRepository = mock(AcompanhamentoRepository.class);
        devolucaoService = new DevolucaoService(
                animalRepository,
                usuarioRepository,
                candidaturaRepository,
                acompanhamentoRepository);
    }

    @Test
    void devolucaoRetornaAnimalCancelaAcompanhamentosEBloqueiaAdotantePorUmAno() {
        Animal animal = new Animal();
        animal.setId(1L);
        animal.setStatus(StatusAnimal.ADOTADO);
        Usuario adotante = new Usuario();
        adotante.setId(2L);
        Acompanhamento acompanhamento = new Acompanhamento();
        acompanhamento.setStatus(StatusAcompanhamento.PENDENTE);

        when(animalRepository.findById(1L)).thenReturn(Optional.of(animal));
        when(usuarioRepository.findById(2L)).thenReturn(Optional.of(adotante));
        when(candidaturaRepository.findByAnimalIdAndAdotanteIdAndStatus(
                1L, 2L, StatusCandidatura.APROVADA))
                .thenReturn(Optional.of(new com.ong.adocao.model.Candidatura()));
        when(acompanhamentoRepository.findByAnimalIdAndAdotanteIdAndStatusIn(
                1L, 2L, List.of(StatusAcompanhamento.PENDENTE, StatusAcompanhamento.ATRASADO)))
                .thenReturn(List.of(acompanhamento));

        devolucaoService.registrarDevolucao(1L, 2L);

        assertEquals(StatusAnimal.EM_TRATAMENTO, animal.getStatus());
        assertEquals(StatusAcompanhamento.CANCELADO, acompanhamento.getStatus());
        assertEquals(LocalDate.now().plusYears(1), adotante.getBloqueadoAte());
        verify(animalRepository).save(animal);
        verify(usuarioRepository).save(adotante);
        verify(acompanhamentoRepository).saveAll(List.of(acompanhamento));
    }
}
