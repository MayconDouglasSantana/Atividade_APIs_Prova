package com.ong.adocao.repository;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ong.adocao.model.Acompanhamento;
import com.ong.adocao.model.StatusAcompanhamento;

public interface AcompanhamentoRepository extends JpaRepository<Acompanhamento, Long> {

    List<Acompanhamento> findByAnimalId(Long animalId);

    List<Acompanhamento> findByStatusAndDataPrevistaBefore(
            StatusAcompanhamento status,
            LocalDate dataPrevista);

    List<Acompanhamento> findByDataPrevistaBeforeAndStatusIn(
            LocalDate dataPrevista,
            Collection<StatusAcompanhamento> statuses);

    List<Acompanhamento> findByAnimalIdAndAdotanteIdAndStatusIn(
            Long animalId,
            Long adotanteId,
            Collection<StatusAcompanhamento> statuses);
}
