package com.ong.adocao.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ong.adocao.model.Candidatura;
import com.ong.adocao.model.StatusCandidatura;

public interface CandidaturaRepository extends JpaRepository<Candidatura, Long> {

    long countByAdotanteIdAndStatus(Long adotanteId, StatusCandidatura status);

    List<Candidatura> findByAnimalId(Long animalId);

    List<Candidatura> findByAdotanteId(Long adotanteId);

    List<Candidatura> findByAnimalIdAndStatus(Long animalId, StatusCandidatura status);

    Optional<Candidatura> findByIdAndAdotanteId(Long id, Long adotanteId);

    Optional<Candidatura> findByAnimalIdAndAdotanteIdAndStatus(
            Long animalId,
            Long adotanteId,
            StatusCandidatura status);

    List<Candidatura> findByStatusAndDataAprovacaoIsNotNull(StatusCandidatura status);
}
