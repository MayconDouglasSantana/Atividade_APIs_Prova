package com.ong.adocao.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ong.adocao.dto.CuidadoSaudeDTO;
import com.ong.adocao.service.CuidadoSaudeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/animais/{id}/cuidados")
public class CuidadoSaudeController {

    private final CuidadoSaudeService cuidadoSaudeService;

    public CuidadoSaudeController(CuidadoSaudeService cuidadoSaudeService) {
        this.cuidadoSaudeService = cuidadoSaudeService;
    }

    @PostMapping
    public ResponseEntity<CuidadoSaudeDTO> registrarCuidado(
            @PathVariable Long id,
            @Valid @RequestBody CuidadoSaudeDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(cuidadoSaudeService.registrarCuidado(id, dto));
    }
}
