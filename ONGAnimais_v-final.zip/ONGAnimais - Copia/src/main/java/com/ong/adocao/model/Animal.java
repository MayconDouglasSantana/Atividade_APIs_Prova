package com.ong.adocao.model;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Version;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Animal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String especie;
    private String porte;
    private String sexo;
    private Integer idadeEstimada;
    private String temperamento;
    private String fotoUrl;
    private LocalDate dataEntrada;

    @Enumerated(EnumType.STRING)
    private StatusAnimal status;

    @Version
    private Long versao;

    @PrePersist
    private void definirDataEntrada() {
        if (dataEntrada == null) {
            dataEntrada = LocalDate.now();
        }
    }
}
